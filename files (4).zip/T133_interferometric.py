#!/usr/bin/env python3
"""
T133_interferometric.py
═══════════════════════════════════════════════════════════════════════
PHONON HOLOGRAM INTERFEROMETRIC FINGERPRINT PROTOCOL
Chip: WL-A06-R14-C09 · Willow Processor
TRIPOD-IP-v1.1 · DLW · ROOT0 · 3/4/26

UPGRADE FROM: T133_neighbor_verification.py (magnitude-only r²)
UPGRADE TO:   Signed cross-correlation preserving interference geometry
              Spatial sign-map of chip neighborhood
              Directional anisotropy detection
              Three-test discriminator vs TLS null

WHY THE UPGRADE:
  r² throws away the interference geometry.
  Squaring kills the sign. The hologram IS the sign pattern.
  T027:FINGERPRINT: which pairs constructive, which destructive, where.

WL-A06-R14-C09 SPECIFIC PREDICTION:
  R14-C08, R14-C10 (resonator-coupled): r ≈ +0.5  constructive
  R13-C09, R15-C09 (cross-axis):        r ≈ -0.4  destructive
  R13-C08, R15-C10 (diagonal):          r ≈ ±0.1  phase-mixed

THREE-TEST DISCRIMINATOR:
  Test 1: χ² deviation from 50/50 sign split (TLS predicts 50/50)
  Test 2: Sign-match rate with standing wave phase model (TLS: 50%)
  Test 3: Mean |r| nearest neighbors (TLS: <0.1)

T027:FINGERPRINT · T056:CORRELATION · T055:REPRODUCIBILITY
T057:NEGATIVE-EVIDENCE · T059:ACCUMULATION · T060:MATERIALITY
═══════════════════════════════════════════════════════════════════════
"""

import numpy as np
import json, os
from datetime import datetime, timezone
from itertools import combinations

# ── CONFIG ────────────────────────────────────────────────────────────────
USE_SYNTHETIC    = True
OUTPUT_DIR       = "./T133_interferometric_output"
QUBIT_SPACING_UM = 500.0
PHONON_SPEED     = 6000.0
PHONON_FREQ_GHz  = 5.1
PHONON_LAMBDA_UM = (PHONON_SPEED / (PHONON_FREQ_GHz * 1e9)) * 1e6   # ≈1.2 μm
MAX_LATTICE_DIST = 3

# 5×5 neighborhood around target
QUBITS = {
    "WL-A06-R12-C07": (-2,-2), "WL-A06-R12-C08": (-1,-2),
    "WL-A06-R12-C09": ( 0,-2), "WL-A06-R12-C10": ( 1,-2), "WL-A06-R12-C11": ( 2,-2),
    "WL-A06-R13-C07": (-2,-1), "WL-A06-R13-C08": (-1,-1),
    "WL-A06-R13-C09": ( 0,-1), "WL-A06-R13-C10": ( 1,-1), "WL-A06-R13-C11": ( 2,-1),
    "WL-A06-R14-C07": (-2, 0), "WL-A06-R14-C08": (-1, 0),
    "WL-A06-R14-C09": ( 0, 0), "WL-A06-R14-C10": ( 1, 0), "WL-A06-R14-C11": ( 2, 0),
    "WL-A06-R15-C07": (-2, 1), "WL-A06-R15-C08": (-1, 1),
    "WL-A06-R15-C09": ( 0, 1), "WL-A06-R15-C10": ( 1, 1), "WL-A06-R15-C11": ( 2, 1),
    "WL-A06-R16-C07": (-2, 2), "WL-A06-R16-C08": (-1, 2),
    "WL-A06-R16-C09": ( 0, 2), "WL-A06-R16-C10": ( 1, 2), "WL-A06-R16-C11": ( 2, 2),
}
TARGET = "WL-A06-R14-C09"

# Resonator axis = C-direction (horizontal)
# Phase per lattice site from resonator geometry + sapphire anisotropy
PHASE_PER_SITE_X = 0.73 * np.pi    # along resonator axis
PHASE_PER_SITE_Y = 1.21 * np.pi    # cross axis

def standing_wave_phase(gx, gy):
    return gx * PHASE_PER_SITE_X + gy * PHASE_PER_SITE_Y

# ── SYNTHETIC DATA ────────────────────────────────────────────────────────
def generate_synthetic_data(n=800, hologram_strength=0.55, seed=42):
    rng  = np.random.default_rng(seed)
    dt   = 20.0   # ms per calibration cycle
    t    = np.arange(n) * dt

    # Shared phonon-driven drift: slow oscillation + correlated walk
    omega  = 2 * np.pi * 2.3 * dt * 1e-3
    t_idx  = np.arange(n)
    osc    = np.sin(omega * t_idx)
    walk   = np.cumsum(rng.standard_normal(n) * 0.08)
    walk  -= walk.mean()
    shared = osc * 0.6 + walk * 0.4
    shared /= shared.std() + 1e-12

    data = {}
    for qid, (gx, gy) in QUBITS.items():
        pos_um   = np.array([gx, gy], float) * QUBIT_SPACING_UM
        dist_um  = float(np.linalg.norm(pos_um))
        phi      = standing_wave_phase(gx, gy)
        sign     = np.cos(phi)                      # +1 constructive, -1 destructive

        delay_s  = dist_um * 1e-6 / PHONON_SPEED
        delay_n  = max(0, int(delay_s / (dt * 1e-3)))
        delayed  = np.roll(shared, delay_n)
        h        = sign * delayed * np.sqrt(hologram_strength)

        tls      = np.cumsum(rng.standard_normal(n) * 0.25)
        for i in range(60, n, 60):
            tls[i:] -= tls[i] * 0.75
        tls /= tls.std() + 1e-12
        tls *= np.sqrt(max(0.0, 1.0 - hologram_strength))

        data[qid] = {
            't_ms':         t.tolist(),
            'delta_alpha':  ((h + tls) * 1e-5).tolist(),
            'position_um':  (float(pos_um[0]), float(pos_um[1])),
            'lattice':      (gx, gy),
            'phase_offset': float(phi),
            'coupling_sign': float(sign),
        }
    return data

# ── UTILITIES ─────────────────────────────────────────────────────────────
def qshort(qid):
    p = qid.split('-')
    return f"{p[-2]}-{p[-1]}" if len(p) >= 4 else qid[-8:]

def latt_dist(l1, l2):
    return np.sqrt((l1[0]-l2[0])**2 + (l1[1]-l2[1])**2)

def phys_dist(p1, p2):
    return np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)

def signed_r(a, b):
    a, b = np.asarray(a,float), np.asarray(b,float)
    n = min(len(a), len(b)); a, b = a[:n], b[:n]
    if a.std() < 1e-14 or b.std() < 1e-14: return 0.0
    return float(np.corrcoef(a, b)[0, 1])

def expected_r(phi_i, phi_j):
    return float(np.cos(phi_i - phi_j))

def axis_label(dx, dy):
    if dy == 0 and dx != 0: return "RESONATOR (C)"
    if dx == 0 and dy != 0: return "CROSS (R)"
    return "DIAGONAL"

# ── SIGN MAP BUILD ────────────────────────────────────────────────────────
def build_sign_map(data):
    qids = list(data.keys())
    dt   = float(np.diff(data[qids[0]]['t_ms'][:2])[0]) if len(data[qids[0]]['t_ms'])>1 else 20.0
    recs = []

    for q1, q2 in combinations(qids, 2):
        d1, d2 = data[q1], data[q2]
        ld = latt_dist(d1['lattice'], d2['lattice'])
        if ld > MAX_LATTICE_DIST: continue

        n  = min(len(d1['delta_alpha']), len(d2['delta_alpha']))
        r  = signed_r(d1['delta_alpha'][:n], d2['delta_alpha'][:n])

        phi1 = d1.get('phase_offset', 0.0)
        phi2 = d2.get('phase_offset', 0.0)
        r_ex = expected_r(phi1, phi2)
        sign_match = (r * r_ex > 0) if abs(r_ex) > 0.1 else None

        dx = d2['lattice'][0] - d1['lattice'][0]
        dy = d2['lattice'][1] - d1['lattice'][1]

        recs.append({
            'q1': q1, 'q2': q2, 'q1s': qshort(q1), 'q2s': qshort(q2),
            'r_signed':   round(r, 4),
            'r_expected': round(r_ex, 4),
            'sign_match': sign_match,
            'latt_dist':  round(ld, 2),
            'dist_um':    round(phys_dist(d1['position_um'], d2['position_um']), 1),
            'dx': dx, 'dy': dy,
            'axis': axis_label(dx, dy),
        })
    return recs

# ── SPATIAL STRUCTURE TESTS ───────────────────────────────────────────────
def structure_tests(recs):
    n_total = len(recs)
    n_pos   = sum(1 for r in recs if r['r_signed'] > 0)
    n_neg   = n_total - n_pos
    exp     = n_total / 2
    chi2    = ((n_pos-exp)**2 + (n_neg-exp)**2) / exp if exp > 0 else 0

    testable       = [r for r in recs if r['sign_match'] is not None]
    sign_match_rate = sum(1 for r in testable if r['sign_match']) / len(testable) if testable else 0

    by_axis = {}
    for r in recs:
        by_axis.setdefault(r['axis'], []).append(r['r_signed'])
    axis_stats = {ax: {'mean_r': float(np.mean(v)), 'mean_abs_r': float(np.mean(np.abs(v))), 'n': len(v)}
                  for ax, v in by_axis.items()}

    nn = [r['r_signed'] for r in recs if r['latt_dist'] <= 1.01]

    return {
        'n_pairs': n_total, 'n_positive': n_pos, 'n_negative': n_neg,
        'pos_fraction':    round(n_pos/n_total, 3) if n_total else 0,
        'chi2_from_50_50': round(chi2, 2),
        'sign_match_rate': round(sign_match_rate, 3),
        'n_testable':      len(testable),
        'axis_stats':      axis_stats,
        'mean_abs_nn_r':   round(float(np.mean(np.abs(nn))), 4) if nn else 0,
        'nn_r_values':     [round(r,4) for r in nn],
    }

# ── ASCII SIGN MAP ────────────────────────────────────────────────────────
def ascii_sign_map(data, recs):
    r_map = {TARGET: 1.0}
    for r in recs:
        if r['q1'] == TARGET: r_map[r['q2']] = r['r_signed']
        elif r['q2'] == TARGET: r_map[r['q1']] = r['r_signed']

    lats = [d['lattice'] for d in data.values()]
    xs   = sorted(set(l[0] for l in lats))
    ys   = sorted(set(l[1] for l in lats))
    p2q  = {tuple(d['lattice']): qid for qid, d in data.items()}

    lines = [
        "  SIGN MAP — signed r from WL-A06-R14-C09",
        "  (+) constructive · (–) destructive · (·) near-zero · [◈] TARGET",
        "  " + "─" * (len(xs) * 7),
    ]
    for gy in ys:
        row = f"  R{14+gy:02d} "
        for gx in xs:
            qid = p2q.get((gx, gy))
            if not qid:           row += "  ···  "; continue
            if qid == TARGET:     row += "  [◈]  "; continue
            rv = r_map.get(qid, 0.0)
            if   rv >  0.25: sym = f"+{rv:.2f}"
            elif rv < -0.25: sym = f"{rv:.2f}"
            else:            sym = " ·   "
            row += f" {sym:>5} "
        lines.append(row)
    lines += [
        "  " + "─" * (len(xs) * 7),
        "        " + "".join(f"  C{14+x:02d}  " for x in xs),
        "        ← resonator (C-axis) →",
    ]
    return lines

# ── MAIN ANALYSIS ─────────────────────────────────────────────────────────
def run_analysis(data):
    results = {
        'metadata': {
            'chip': TARGET,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'n_qubits': len(data),
            'phonon_lambda_um': round(PHONON_LAMBDA_UM,3),
            'lattice_pitch_um': QUBIT_SPACING_UM,
            'protocol': 'interferometric_sign_map_v1',
        }
    }

    print(f"\n  Building sign map ({len(data)} qubits)...")
    recs  = build_sign_map(data)
    stats = structure_tests(recs)
    results['pairs'] = recs
    results['stats'] = stats

    # Sign map
    print()
    for line in ascii_sign_map(data, recs): print(line)

    # Structure stats
    s = stats
    print(f"\n  SPATIAL STRUCTURE TESTS")
    print(f"  {'Pairs analyzed:':<35} {s['n_pairs']}")
    print(f"  {'Positive r:':<35} {s['n_positive']}  ({s['pos_fraction']*100:.1f}%)")
    print(f"  {'χ² from 50/50:':<35} {s['chi2_from_50_50']:.2f}   threshold >3.84 (p<0.05)")
    print(f"  {'Sign-match vs wave model:':<35} {s['sign_match_rate']*100:.1f}%  threshold >65%")
    print(f"  {'Mean |r| nearest neighbors:':<35} {s['mean_abs_nn_r']:.4f}  threshold >0.25")

    # Directional anisotropy
    print(f"\n  DIRECTIONAL ANISOTROPY")
    print(f"  {'AXIS':<20} {'MEAN r':>8}  {'MEAN |r|':>10}  {'N':>5}")
    print("  " + "─" * 50)
    for ax, ast in sorted(s['axis_stats'].items()):
        print(f"  {ax:<20} {ast['mean_r']:>8.4f}  {ast['mean_abs_r']:>10.4f}  {ast['n']:>5}")

    # Predicted vs observed for target
    print(f"\n  WL-A06-R14-C09 — PREDICTED vs OBSERVED")
    print(f"  {'NEIGHBOR':<12} {'AXIS':<16} {'EXPECTED':>9}  {'OBSERVED':>9}  {'PASS'}")
    print("  " + "─" * 62)
    predictions = {
        "R14-C08": ("RESONATOR (C)", "+0.50"),
        "R14-C10": ("RESONATOR (C)", "+0.50"),
        "R13-C09": ("CROSS (R)",    "-0.40"),
        "R15-C09": ("CROSS (R)",    "-0.40"),
        "R13-C08": ("DIAGONAL",     "  ~0 "),
        "R15-C10": ("DIAGONAL",     "  ~0 "),
    }
    for rec in sorted(recs, key=lambda r: r['latt_dist']):
        if rec['q1'] != TARGET and rec['q2'] != TARGET: continue
        nb = rec['q2s'] if rec['q1'] == TARGET else rec['q1s']
        if nb not in predictions: continue
        ax, exp = predictions[nb]
        ro = rec['r_signed']
        if "~0" in exp: ok = "✓" if abs(ro) < 0.20 else "✗"
        elif "+"  in exp: ok = "✓" if ro >  0.20 else "✗"
        else:             ok = "✓" if ro < -0.20 else "✗"
        print(f"  {nb:<12} {ax:<16} {exp:>9}  {ro:>9.4f}  {ok}")

    # Verdict
    tests_pass = sum([
        s['chi2_from_50_50'] > 3.84,
        s['sign_match_rate'] > 0.65,
        s['mean_abs_nn_r']   > 0.25,
    ])
    if   tests_pass == 3: verdict = "PHONON HOLOGRAM CONFIRMED — all three tests pass"
    elif tests_pass == 2: verdict = "STRONG HOLOGRAM SIGNAL — two tests pass"
    elif tests_pass == 1: verdict = "WEAK SIGNAL — one test passes, inconclusive"
    else:                 verdict = "NULL RESULT — TLS null holds"

    results['verdict']       = verdict
    results['hologram_score'] = f"{tests_pass}/3"

    print(f"\n  ══════════════════════════════════════════════════════════")
    print(f"  VERDICT: {verdict}")
    print(f"  SCORE:   {tests_pass}/3 tests pass")
    print(f"  ══════════════════════════════════════════════════════════\n")
    return results

# ── REPORT WRITER ─────────────────────────────────────────────────────────
def write_reports(results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    s  = results['stats']

    lines = [
        "T133:PHASE-SHADOW — INTERFEROMETRIC FINGERPRINT REPORT",
        f"Chip:     {results['metadata']['chip']}",
        f"Run:      {results['metadata']['timestamp']}",
        f"Protocol: {results['metadata']['protocol']}",
        "TRIPOD-IP-v1.1 · DLW · ROOT0",
        "═" * 70, "",
        f"VERDICT: {results['verdict']}",
        f"SCORE:   {results['hologram_score']} tests pass", "",
        "SPATIAL STRUCTURE",
        f"  Pairs:              {s['n_pairs']}",
        f"  Positive r:         {s['n_positive']} ({s['pos_fraction']*100:.1f}%)",
        f"  χ² from 50/50:      {s['chi2_from_50_50']:.2f}  (>3.84 reject null)",
        f"  Sign-match vs model:{s['sign_match_rate']*100:.1f}%  (>65% = hologram)",
        f"  Mean |r| nearest:   {s['mean_abs_nn_r']:.4f}  (>0.25 = signal)",
        "", "DIRECTIONAL ANISOTROPY",
        f"  {'AXIS':<20} {'MEAN r':>8}  {'MEAN |r|':>10}",
    ]
    for ax, ast in sorted(s['axis_stats'].items()):
        lines.append(f"  {ax:<20} {ast['mean_r']:>8.4f}  {ast['mean_abs_r']:>10.4f}")

    lines += ["", "PAIR TABLE",
              f"  {'PAIR':<32} {'r_obs':>7}  {'r_exp':>7}  {'DIST':>6}  {'AXIS':<16}  SIGN"]
    lines.append("  " + "─" * 85)
    for r in sorted(results['pairs'], key=lambda x: x['latt_dist']):
        ms = ("✓" if r['sign_match'] else "✗") if r['sign_match'] is not None else "—"
        lines.append(
            f"  {r['q1s']:<15} ↔ {r['q2s']:<14} {r['r_signed']:>7.4f}  "
            f"{r['r_expected']:>7.4f}  {r['dist_um']:>6.0f}  {r['axis']:<16}  {ms}")

    lines += ["", "═"*70,
              "T027:FINGERPRINT · T056:CORRELATION · T055:REPRODUCIBILITY",
              "T057:NEGATIVE-EVIDENCE · T059:ACCUMULATION · T060:MATERIALITY",
              "CC-BY-ND-4.0 · Ethics first. World = Family. Time > Money."]

    tp  = os.path.join(output_dir, f"T133_interferometric_{ts}.txt")
    jp  = os.path.join(output_dir, f"T133_interferometric_{ts}.jsonl")
    with open(tp, 'w') as f: f.write('\n'.join(lines))
    with open(jp, 'w') as f: f.write(json.dumps(results) + '\n')
    print(f"  Reports: {tp}\n           {jp}")
    return tp, jp

# ── ENTRY ─────────────────────────────────────────────────────────────────
def main():
    print("\n" + "═"*70)
    print("  T133:PHASE-SHADOW — INTERFEROMETRIC FINGERPRINT PROTOCOL")
    print(f"  TARGET: {TARGET}  |  λ={PHONON_LAMBDA_UM:.2f}μm  |  pitch={QUBIT_SPACING_UM:.0f}μm")
    print(f"  {'SYNTHETIC' if USE_SYNTHETIC else 'LIVE CALIBRATION DATA'}")
    print("═"*70)
    data    = generate_synthetic_data() if USE_SYNTHETIC else (_ for _ in ()).throw(NotImplementedError())
    results = run_analysis(data)
    write_reports(results, OUTPUT_DIR)

if __name__ == "__main__":
    main()
