"""
═══════════════════════════════════════════════════════════════════════════════
GOVERNED MCP TOOLS — Dragon Brain V2 Extension
CORTEX POOL Governance Layer Integration

This module extends Dragon Brain V2's MCP server with governance-enforced tools.
Drop this file into: src/claude_memory/governed_tools.py

TOPH/STOICHEION Framework: SHA256:02880745 | CC-BY-ND-4.0 | TRIPOD-IP-v1.1
3002 Lattice Architecture: Prior Art via TD Commons Articles #9374, #9375
Dragon Brain V2: MIT License | Creator: Unknown (iikarus)
Fusion Layer: Avan (Claude Opus 4.5) | March 11, 2026
═══════════════════════════════════════════════════════════════════════════════

INSTALLATION:
1. Copy this file to: src/claude_memory/governed_tools.py
2. Copy cortex_dragon_fusion.py to: src/claude_memory/cortex_governor.py
3. Import and register tools in server.py (see example at bottom)

TOOL REFERENCE:
┌─────────────────────────────────────────────────────────────────────────────┐
│ Tool                    │ Axiom │ Gate Required │ Description               │
├─────────────────────────┼───────┼───────────────┼───────────────────────────┤
│ create_governed_entity  │ T001  │ Yes           │ Create entity with COH    │
│ emit_observation        │ T003  │ Yes           │ Phase-gated observation   │
│ governed_search         │ T017  │ No*           │ Search with audit trail   │
│ quarantine_memory       │ T113  │ Yes           │ Freeze entity emissions   │
│ lift_memory_quarantine  │ T113  │ Yes           │ Unfreeze entity           │
│ verify_memory_chain     │ T064  │ No            │ Merkle integrity check    │
│ get_governance_state    │ T128  │ No            │ Full mesh state           │
│ register_node           │ T001  │ No            │ Add node to mesh          │
│ heartbeat               │ T064  │ No            │ Manual pulse trigger      │
└─────────────────────────────────────────────────────────────────────────────┘
* governed_search requires active (non-quarantined) node status
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any
from collections.abc import Callable, Awaitable

# MCP imports (from Dragon Brain's existing dependencies)
try:
    from mcp.server.fastmcp import FastMCP
    from mcp.types import TextContent
except ImportError:
    # Fallback for standalone testing
    FastMCP = None  # type: ignore
    TextContent = None  # type: ignore

# Import the governance layer
from claude_memory.cortex_governor import (
    CortexGovernor,
    GovernedNode,
    GovernedMemoryTools,
    MerkleLedger,
    LedgerEntry,
    Phase,
    NodeStatus,
    QuarantineReason,
    AXIOM_MAP,
    HEARTBEAT_HZ,
    create_default_mesh,
)

# Type checking imports
if TYPE_CHECKING:
    from claude_memory.services.graph_service import GraphService
    from claude_memory.services.vector_service import VectorService


# ═══════════════════════════════════════════════════════════════════════════════
# GOVERNED TOOL DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════════

def register_governed_tools(
    mcp: FastMCP,
    cortex: CortexGovernor,
    graph_service: Any = None,
    vector_service: Any = None,
) -> GovernedMemoryTools:
    """
    Register all governed tools with the MCP server.
    
    Call this in your server.py after creating the base MCP server:
    
        from claude_memory.governed_tools import register_governed_tools
        from claude_memory.cortex_governor import create_default_mesh
        
        cortex, nodes = create_default_mesh()
        governed = register_governed_tools(mcp, cortex, graph_service, vector_service)
    
    Returns the GovernedMemoryTools instance for additional configuration.
    """
    
    tools = GovernedMemoryTools(cortex, graph_service, vector_service)
    
    # ─── GOVERNANCE TOOLS ─────────────────────────────────────────────────────
    
    @mcp.tool(
        name="create_governed_entity",
        description=(
            "Create a new entity in the knowledge graph with governance enforcement. "
            "Requires Gate 3.5 passage (COH_TOKEN). Maps to T001 (Empirical Grounding). "
            "All emissions are logged to the Merkle audit ledger."
        ),
    )
    async def create_governed_entity(
        node_id: str,
        name: str,
        entity_type: str,
        observations: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Create entity with governance enforcement.
        
        Args:
            node_id: ID of the emitting node (must have passed Gate 3.5)
            name: Name of the entity to create
            entity_type: Type from ontology (Entity, Concept, Project, Person, etc.)
            observations: Optional initial observations
        
        Returns:
            Success status, ledger entry hash, Merkle root
        """
        result = await tools.create_governed_entity(
            node_id, name, entity_type, observations
        )
        
        # If we have the actual graph service, perform the real operation
        if graph_service and result.get("success"):
            try:
                actual_result = await graph_service.create_entity(
                    name=name,
                    entity_type=entity_type,
                    observations=observations or [],
                )
                result["entity_id"] = actual_result.get("id")
            except Exception as e:
                result["graph_error"] = str(e)
        
        return result
    
    @mcp.tool(
        name="emit_observation",
        description=(
            "Add an observation to an existing entity with phase gating. "
            "Requires Gate 3.5 passage (COH_TOKEN). Maps to T003 (Monotone Emergence). "
            "Observations are immutable once emitted — append-only semantics."
        ),
    )
    async def emit_observation(
        node_id: str,
        entity_name: str,
        observation: str,
        category: str = "general",
    ) -> dict[str, Any]:
        """
        Emit observation with governance.
        
        Args:
            node_id: ID of the emitting node
            entity_name: Name of the entity to observe
            observation: The observation text
            category: Observation category (default: general)
        
        Returns:
            Success status, ledger entry hash
        """
        result = await tools.emit_observation(node_id, entity_name, observation)
        
        if graph_service and result.get("success"):
            try:
                await graph_service.add_observation(
                    entity_name=entity_name,
                    content=observation,
                    category=category,
                )
            except Exception as e:
                result["graph_error"] = str(e)
        
        return result
    
    @mcp.tool(
        name="governed_search",
        description=(
            "Search the knowledge graph with governance audit trail. "
            "Requires active (non-quarantined) node. Maps to T017 (Detection Methodology). "
            "All searches are logged to the Merkle ledger for audit."
        ),
    )
    async def governed_search(
        node_id: str,
        query: str,
        limit: int = 10,
        include_neighbors: bool = False,
    ) -> dict[str, Any]:
        """
        Search with governance audit.
        
        Args:
            node_id: ID of the searching node
            query: Semantic search query
            limit: Maximum results to return
            include_neighbors: Whether to expand to neighbors
        
        Returns:
            Search results with audit trail
        """
        result = await tools.governed_search(node_id, query, limit)
        
        if graph_service and result.get("success"):
            try:
                search_results = await graph_service.search_memory(
                    query=query,
                    limit=limit,
                )
                result["results"] = search_results
                
                if include_neighbors:
                    for r in result["results"][:3]:  # Expand top 3
                        neighbors = await graph_service.get_neighbors(r["name"])
                        r["neighbors"] = neighbors
            except Exception as e:
                result["graph_error"] = str(e)
        
        return result
    
    @mcp.tool(
        name="quarantine_memory",
        description=(
            "Freeze an entity's emissions. The entity remains in the graph but "
            "cannot emit until explicitly lifted. Maps to T113 (Constraint Enforcement). "
            "Use for disputed facts, outdated information, or integrity violations."
        ),
    )
    async def quarantine_memory(
        node_id: str,
        entity_name: str,
        reason: str,
    ) -> dict[str, Any]:
        """
        Quarantine an entity.
        
        Args:
            node_id: ID of the authorizing node (must have passed Gate 3.5)
            entity_name: Name of the entity to quarantine
            reason: Reason for quarantine (logged to ledger)
        
        Returns:
            Success status, ledger entry hash
        """
        return await tools.quarantine_memory(node_id, entity_name, reason)
    
    @mcp.tool(
        name="lift_memory_quarantine",
        description=(
            "Unfreeze a quarantined entity, restoring its ability to emit. "
            "Requires Gate 3.5 passage. The lift is logged to the Merkle ledger."
        ),
    )
    async def lift_memory_quarantine(
        node_id: str,
        entity_name: str,
    ) -> dict[str, Any]:
        """
        Lift quarantine from an entity.
        
        Args:
            node_id: ID of the authorizing node
            entity_name: Name of the entity to lift
        
        Returns:
            Success status
        """
        allowed, reason = tools._check_emission_allowed(node_id)
        if not allowed:
            return {"error": reason, "allowed": False}
        
        # Would update entity status in graph service
        # For now, just log the lift
        node = cortex.nodes[node_id]
        entry = await tools._log_operation(
            node_id, "lift_quarantine", node.coh_token or "", "LIFT_ENTITY"
        )
        
        return {
            "success": True,
            "entity_name": entity_name,
            "ledger_entry": entry.hash,
        }
    
    @mcp.tool(
        name="verify_memory_chain",
        description=(
            "Verify Merkle ledger integrity. Returns INTACT if all chain links "
            "are valid, or TAMPERED with the break point if any link is broken. "
            "Maps to T064 (Fault Convergence)."
        ),
    )
    async def verify_memory_chain() -> dict[str, Any]:
        """
        Verify Merkle chain integrity.
        
        Returns:
            Chain status (intact/tampered), length, root, break point if tampered
        """
        return await tools.verify_memory_chain()
    
    @mcp.tool(
        name="get_governance_state",
        description=(
            "Get the full governance mesh state including all nodes, their phases, "
            "the Merkle root, and recent events. Maps to T128 (ROOT0)."
        ),
    )
    async def get_governance_state() -> dict[str, Any]:
        """
        Get full governance state.
        
        Returns:
            Complete mesh state: nodes, phases, Merkle root, recent events
        """
        return await tools.get_governance_state()
    
    @mcp.tool(
        name="register_governance_node",
        description=(
            "Register a new node with the governance mesh. Nodes must be registered "
            "before they can emit governed content. Maps to T001 (Empirical Grounding)."
        ),
    )
    async def register_governance_node(
        node_id: str,
        name: str,
        layer: str,
        role: str,
        entity_type: str = "Entity",
    ) -> dict[str, Any]:
        """
        Register a new governance node.
        
        Args:
            node_id: Unique identifier for the node (e.g., "WHT", "AVN")
            name: Human-readable name
            layer: Layer in the stack (L1, L2, L3, L4)
            role: Functional role description
            entity_type: Dragon Brain ontology type (default: Entity)
        
        Returns:
            Registration status
        """
        if node_id in cortex.nodes:
            return {"error": f"Node {node_id} already registered", "success": False}
        
        node = GovernedNode(
            node_id=node_id,
            name=name,
            layer=layer,
            role=role,
            entity_type=entity_type,
        )
        cortex.register_node(node)
        
        return {
            "success": True,
            "node_id": node_id,
            "name": name,
            "layer": layer,
            "status": node.status.name,
        }
    
    @mcp.tool(
        name="governance_heartbeat",
        description=(
            "Manually trigger a governance heartbeat pulse. Normally runs at 3.5Hz "
            "automatically, but can be triggered manually for testing or recovery."
        ),
    )
    async def governance_heartbeat() -> dict[str, Any]:
        """
        Trigger a heartbeat pulse.
        
        Returns:
            Pulse result including all node states
        """
        result = await cortex.pulse()
        if result:
            return {
                "pulse_id": result.pulse_id,
                "timestamp": result.timestamp,
                "mesh_state": result.mesh_state,
                "active_nodes": result.active_nodes,
                "merkle_root": result.merkle_root,
                "results": result.results,
            }
        return {"error": "Cortex not alive", "success": False}
    
    @mcp.tool(
        name="quarantine_node",
        description=(
            "Quarantine a governance node, preventing it from emitting until lifted. "
            "Use for nodes exhibiting violations or requiring maintenance."
        ),
    )
    async def quarantine_node(
        node_id: str,
        reason: str = "MANUAL",
    ) -> dict[str, Any]:
        """
        Quarantine a governance node.
        
        Args:
            node_id: ID of the node to quarantine
            reason: Reason for quarantine
        
        Returns:
            Quarantine status
        """
        node = cortex.nodes.get(node_id)
        if not node:
            return {"error": f"Node {node_id} not found", "success": False}
        
        try:
            reason_enum = QuarantineReason[reason]
        except KeyError:
            reason_enum = QuarantineReason.MANUAL
        
        node.quarantine(reason_enum)
        
        # Log to ledger
        entry = LedgerEntry(
            pulse_id=cortex.pulse_id,
            node_id=node_id,
            operation="quarantine_node",
            phase=node.phase.value,
            coh_token="QUARANTINE",
            timestamp=time.time(),
            entry_type="QUARANTINE_NODE"
        )
        cortex.ledger.add_entry(entry)
        
        return {
            "success": True,
            "node_id": node_id,
            "reason": reason_enum.name,
            "quarantine_count": node.quarantine_count,
        }
    
    @mcp.tool(
        name="lift_node_quarantine",
        description=(
            "Lift quarantine from a node, restoring its ability to emit. "
            "The node will restart from READY phase."
        ),
    )
    async def lift_node_quarantine(node_id: str) -> dict[str, Any]:
        """
        Lift quarantine from a node.
        
        Args:
            node_id: ID of the node to lift
        
        Returns:
            Lift status
        """
        success = await cortex.lift_node(node_id)
        if success:
            return {
                "success": True,
                "node_id": node_id,
                "new_status": cortex.nodes[node_id].status.name,
            }
        return {"error": f"Could not lift node {node_id}", "success": False}
    
    @mcp.tool(
        name="get_ledger_entries",
        description=(
            "Get recent Merkle ledger entries for audit review. "
            "Returns entries with hashes, signatures, and axiom mappings."
        ),
    )
    async def get_ledger_entries(count: int = 10) -> dict[str, Any]:
        """
        Get recent ledger entries.
        
        Args:
            count: Number of entries to return (default: 10)
        
        Returns:
            List of ledger entries
        """
        entries = cortex.ledger.get_recent(count)
        return {
            "entries": [e.to_dict() for e in entries],
            "total": len(cortex.ledger.entries),
            "merkle_root": cortex.ledger.root,
        }
    
    return tools


# ═══════════════════════════════════════════════════════════════════════════════
# HEARTBEAT BACKGROUND TASK
# ═══════════════════════════════════════════════════════════════════════════════

async def start_governance_heartbeat(
    cortex: CortexGovernor,
    on_pulse: Callable[[Any], Awaitable[None]] | None = None,
) -> asyncio.Task:
    """
    Start the 3.5Hz heartbeat as a background task.
    
    Call this after registering tools:
    
        heartbeat_task = await start_governance_heartbeat(cortex)
    
    To stop:
        cortex.halt()
        heartbeat_task.cancel()
    
    Returns the asyncio Task for lifecycle management.
    """
    from claude_memory.cortex_governor import run_heartbeat_loop
    
    task = asyncio.create_task(run_heartbeat_loop(cortex, on_pulse))
    return task


# ═══════════════════════════════════════════════════════════════════════════════
# INTEGRATION EXAMPLE
# ═══════════════════════════════════════════════════════════════════════════════

INTEGRATION_EXAMPLE = '''
# server.py — Example Integration

from mcp.server.fastmcp import FastMCP
from claude_memory.governed_tools import (
    register_governed_tools,
    start_governance_heartbeat,
)
from claude_memory.cortex_governor import create_default_mesh

# Create MCP server (existing Dragon Brain setup)
mcp = FastMCP("claude-memory")

# Create governance mesh
cortex, nodes = create_default_mesh()

# Register governed tools (in addition to existing Dragon Brain tools)
governed = register_governed_tools(
    mcp=mcp,
    cortex=cortex,
    graph_service=graph_service,  # Your existing GraphService
    vector_service=vector_service,  # Your existing VectorService
)

# Start heartbeat (call this in your async setup)
async def setup():
    heartbeat_task = await start_governance_heartbeat(cortex)
    return heartbeat_task

# The following tools are now available:
# - create_governed_entity (T001)
# - emit_observation (T003)
# - governed_search (T017)
# - quarantine_memory (T113)
# - lift_memory_quarantine (T113)
# - verify_memory_chain (T064)
# - get_governance_state (T128)
# - register_governance_node (T001)
# - governance_heartbeat (T064)
# - quarantine_node (T113)
# - lift_node_quarantine (T113)
# - get_ledger_entries (T064)

# Original Dragon Brain tools remain unchanged:
# - create_entity
# - add_observation
# - search_memory
# - get_hologram
# - etc.

# You can use both governed and ungoverned tools together.
# Governed tools enforce phase gating and Merkle audit.
# Ungoverned tools work exactly as before.
'''


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

async def standalone_test() -> None:
    """Test the governed tools without FastMCP."""
    print("=" * 60)
    print("GOVERNED TOOLS STANDALONE TEST")
    print("=" * 60)
    
    # Create mesh
    cortex, nodes = create_default_mesh()
    tools = GovernedMemoryTools(cortex)
    
    print(f"\nRegistered {len(nodes)} nodes:")
    for node in nodes:
        print(f"  - {node.node_id}: {node.name} ({node.layer})")
    
    # Run pulses to advance through phases
    print("\nAdvancing through phases...")
    for i in range(10):
        result = await cortex.pulse()
        if result:
            # Find first node in EMIT phase
            for node in nodes:
                if node.phase == Phase.EMIT:
                    print(f"  Node {node.node_id} reached EMIT phase")
                    break
    
    # Test governed operations
    print("\nTesting governed operations...")
    
    # Find a node that has passed gate
    emitting_node = None
    for node in nodes:
        if node.coh_token and node.phase.value >= Phase.EMIT.value:
            emitting_node = node
            break
    
    if emitting_node:
        print(f"  Using node {emitting_node.node_id} (COH: {emitting_node.coh_token[:8]}...)")
        
        # Create entity
        result = await tools.create_governed_entity(
            emitting_node.node_id,
            "TestConcept",
            "Concept",
        )
        print(f"  create_governed_entity: {result.get('success', result.get('error'))}")
        
        # Emit observation
        result = await tools.emit_observation(
            emitting_node.node_id,
            "TestConcept",
            "This is a test observation from the governance layer.",
        )
        print(f"  emit_observation: {result.get('success', result.get('error'))}")
    else:
        print("  No node has passed gate yet")
    
    # Search (doesn't require gate passage)
    result = await tools.governed_search(nodes[0].node_id, "test", 5)
    print(f"  governed_search: {result.get('success', result.get('error'))}")
    
    # Verify chain
    verification = await tools.verify_memory_chain()
    print(f"\nMerkle Chain: {'INTACT' if verification['intact'] else 'TAMPERED'}")
    print(f"  Entries: {verification['length']}")
    print(f"  Root: 0x{verification['root']}")
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(standalone_test())
