"""
═══════════════════════════════════════════════════════════════════════════════
CORTEX DRAGON FUSION v1.0
Governance Layer for Dragon Brain V2

This module fuses CORTEX POOL governance with Dragon Brain V2 memory infrastructure.
- Phase enforcement (Gate 3.5)
- 3.5Hz heartbeat synchronization
- Quarantine engine
- Merkle audit ledger
- COH_TOKEN requirements for emissions

TOPH/STOICHEION Framework: SHA256:02880745 | CC-BY-ND-4.0 | TRIPOD-IP-v1.1
Dragon Brain V2: MIT License | Creator: Unknown (iikarus)
Fusion: Avan (Claude Opus 4.5) | March 11, 2026

Prior Art: 3002 Lattice Architecture, TD Commons Articles #9374, #9375
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import hashlib
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, TypeVar, Generic
from collections.abc import Callable, Awaitable
import json


# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS — TOPH AXIOM MAPPING
# ═══════════════════════════════════════════════════════════════════════════════

# Heartbeat configuration
HEARTBEAT_HZ = 3.5
HEARTBEAT_INTERVAL = 1.0 / HEARTBEAT_HZ  # ~285.7ms
CLOCK_DRIFT_TOLERANCE = 1  # ±1 cycle

# Axiom mappings (Dragon Brain tool → TOPH axiom)
AXIOM_MAP = {
    "create_entity": "T001",      # Empirical grounding
    "add_observation": "T003",    # Monotone emergence
    "search_memory": "T017",      # Detection methodology
    "get_hologram": "T033",       # Architecture retrieval
    "create_relationship": "T034", # Structural linking
    "get_neighbors": "T035",      # Graph traversal
    "point_in_time_query": "T043", # CANVAS (frozen state)
    "record_breakthrough": "T054", # Frozen events
    "run_librarian_cycle": "T097", # Conductor orchestration
    "graph_health": "T064",       # Fault convergence
}

# Phase definitions
class Phase(Enum):
    """The 8-phase cycle plus Gate 3.5."""
    READY = 0
    ANCHOR = 1        # Interior: receive, hash, establish identity
    WITNESS = 2       # Interior: process, orient, get countersigned
    COHERE = 3        # Interior: crystallize into COH_TOKEN
    GATE = 3.5        # Gate: all locks must clear
    EMIT = 4          # Exterior: first outward signal
    PROPAGATE = 5     # Exterior: signal reaches other nodes
    RESONATE = 6      # Exterior: echo returns, integrity verified
    CONVERGE = 7      # Exterior: nodes align on shared state
    SETTLE = 8        # Exterior: cycle complete

    @property
    def arc(self) -> str:
        """Return the arc this phase belongs to."""
        if self.value == 0:
            return "ready"
        elif self.value <= 3:
            return "interior"
        elif self.value == 3.5:
            return "gate"
        else:
            return "exterior"

    @property
    def is_interior(self) -> bool:
        return self.arc == "interior"

    @property
    def is_exterior(self) -> bool:
        return self.arc == "exterior"


class NodeStatus(Enum):
    """Status states for governed nodes."""
    INITIALIZING = auto()
    ACTIVE = auto()
    QUARANTINED = auto()
    REANCHORING = auto()
    HALTED = auto()


class QuarantineReason(Enum):
    """Reasons for quarantine."""
    EXTERIOR_BEFORE_INTERIOR = auto()
    CLOCK_DRIFT = auto()
    MISSING_COH_TOKEN = auto()
    MISSING_COUNTERSIGN = auto()
    MANUAL = auto()
    GATE_VIOLATION = auto()


# ═══════════════════════════════════════════════════════════════════════════════
# CRYPTOGRAPHIC UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════

def sha256(data: str) -> str:
    """Compute SHA256 hash of string data."""
    return hashlib.sha256(data.encode()).hexdigest()


def truncate_hash(hash_value: str, bits: int = 128) -> str:
    """Truncate hash to specified bit length (as hex chars)."""
    return hash_value[:bits // 4]


def generate_coh_token(
    anchor_id: str,
    witness_sig: str,
    phase_hash: str,
    timestamp: float
) -> str:
    """
    Generate COH_TOKEN per Purple Book spec.
    
    COH_TOKEN = SHA256(Anchor_ID ║ Witness_Sig ║ Phase_Hash ║ Timestamp)
    """
    data = f"{anchor_id}|{witness_sig}|{phase_hash}|{timestamp}"
    return truncate_hash(sha256(data), 64)


# ═══════════════════════════════════════════════════════════════════════════════
# MERKLE AUDIT LEDGER
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class LedgerEntry:
    """Single entry in the Merkle audit ledger."""
    pulse_id: int
    node_id: str
    operation: str
    phase: float
    coh_token: str | None
    timestamp: float
    entry_type: str  # EMIT, QUARANTINE, LIFT, CREATE, etc.
    
    # Computed fields
    hash: str = ""
    prev_hash: str = ""
    node_sig: str = ""
    mesh_sig: str = ""
    root0_sig: str = ""
    axiom: str = ""
    
    def compute_signatures(self, prev_hash: str) -> None:
        """Compute all signatures for this entry."""
        self.prev_hash = prev_hash
        
        entry_data = (
            f"{self.pulse_id}|{self.node_id}|{self.operation}|"
            f"{self.phase}|{self.coh_token}|{self.timestamp}"
        )
        self.hash = truncate_hash(sha256(entry_data + prev_hash), 64)
        self.node_sig = truncate_hash(sha256(f"{self.node_id}_{self.hash}"), 32)
        self.mesh_sig = truncate_hash(sha256(f"MESH_{self.hash}"), 32)
        self.root0_sig = truncate_hash(sha256(f"ROOT0_{self.hash}"), 32)
        self.axiom = AXIOM_MAP.get(self.operation, "T000")
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "pulse_id": self.pulse_id,
            "node_id": self.node_id,
            "operation": self.operation,
            "phase": self.phase,
            "coh_token": self.coh_token,
            "timestamp": self.timestamp,
            "entry_type": self.entry_type,
            "hash": self.hash,
            "prev_hash": self.prev_hash,
            "node_sig": self.node_sig,
            "mesh_sig": self.mesh_sig,
            "root0_sig": self.root0_sig,
            "axiom": self.axiom,
        }


@dataclass
class ChainVerification:
    """Result of chain verification."""
    intact: bool
    length: int
    root: str
    break_at: int | None = None
    expected: str | None = None
    actual: str | None = None


class MerkleLedger:
    """
    Chain-linked audit ledger with triple signatures.
    
    Every entry points to the previous via prev_hash.
    Each entry has node_sig, mesh_sig, and root0_sig.
    Merkle root is recomputed on each addition.
    """
    
    GENESIS_HASH = "0" * 16
    
    def __init__(self) -> None:
        self.entries: list[LedgerEntry] = []
        self.root: str = "0000"
    
    def add_entry(self, entry: LedgerEntry) -> LedgerEntry:
        """Add entry to ledger with chain linking."""
        prev_hash = (
            self.entries[-1].hash if self.entries 
            else self.GENESIS_HASH
        )
        entry.compute_signatures(prev_hash)
        self.entries.append(entry)
        self.root = truncate_hash(entry.hash, 32)
        return entry
    
    def verify_chain(self) -> ChainVerification:
        """
        Verify entire chain integrity.
        
        Returns INTACT if all prev_hash pointers are valid.
        Returns TAMPERED with break point if any link is broken.
        """
        if not self.entries:
            return ChainVerification(intact=True, length=0, root=self.root)
        
        # Check genesis
        if self.entries[0].prev_hash != self.GENESIS_HASH:
            return ChainVerification(
                intact=False, length=len(self.entries), root=self.root,
                break_at=0, expected=self.GENESIS_HASH, 
                actual=self.entries[0].prev_hash
            )
        
        # Check chain links
        for i in range(1, len(self.entries)):
            expected = self.entries[i - 1].hash
            actual = self.entries[i].prev_hash
            if expected != actual:
                return ChainVerification(
                    intact=False, length=len(self.entries), root=self.root,
                    break_at=i, expected=expected, actual=actual
                )
        
        return ChainVerification(
            intact=True, length=len(self.entries), root=self.root
        )
    
    def get_recent(self, count: int = 10) -> list[LedgerEntry]:
        """Get most recent entries."""
        return list(reversed(self.entries[-count:]))
    
    def export(self) -> list[dict[str, Any]]:
        """Export full ledger for external storage."""
        return [entry.to_dict() for entry in self.entries]


# ═══════════════════════════════════════════════════════════════════════════════
# GOVERNED NODE
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GateCheckResult:
    """Result of Gate 3.5 check."""
    passed: bool
    checks: dict[str, bool] = field(default_factory=dict)
    failed_checks: list[str] = field(default_factory=list)


@dataclass
class GovernedNode:
    """
    A node in the CORTEX mesh with phase enforcement.
    
    Maps to Dragon Brain entity types but adds:
    - Phase state tracking
    - COH_TOKEN requirement
    - Quarantine capability
    - Clock synchronization
    """
    
    node_id: str
    name: str
    layer: str  # L1, L2, L3, L4
    role: str
    entity_type: str  # From Dragon Brain ontology
    
    # State
    phase: Phase = Phase.READY
    status: NodeStatus = NodeStatus.INITIALIZING
    coh_token: str | None = None
    countersigned_by: str | None = None
    
    # Metrics
    clock_drift: float = 0.0
    last_pulse: float = 0.0
    emissions: int = 0
    quarantine_count: int = 0
    
    # Reference to cortex (set after creation)
    _cortex: Any = None
    
    def attach_cortex(self, cortex: CortexGovernor) -> None:
        """Attach reference to governing cortex."""
        self._cortex = cortex
    
    async def process_heartbeat(
        self, 
        pulse_id: int, 
        timestamp: float
    ) -> dict[str, Any]:
        """
        Process incoming heartbeat pulse.
        
        Returns action taken and any violations detected.
        """
        if self.status == NodeStatus.QUARANTINED:
            return {"action": "QUARANTINED", "node": self.node_id}
        
        # Check clock drift
        if self.last_pulse > 0:
            expected_delta = HEARTBEAT_INTERVAL
            actual_delta = timestamp - self.last_pulse
            self.clock_drift = abs(actual_delta - expected_delta) / expected_delta
            
            if self.clock_drift > CLOCK_DRIFT_TOLERANCE:
                return {
                    "action": "DRIFT_VIOLATION",
                    "node": self.node_id,
                    "drift": self.clock_drift
                }
        
        self.last_pulse = timestamp
        return await self._advance_phase(pulse_id, timestamp)
    
    async def _advance_phase(
        self, 
        pulse_id: int, 
        timestamp: float
    ) -> dict[str, Any]:
        """Advance to next phase with enforcement."""
        phases = list(Phase)
        current_idx = phases.index(self.phase)
        
        if current_idx >= len(phases) - 1:
            # Cycle complete
            self.phase = Phase.READY
            self.coh_token = None
            self.countersigned_by = None
            self.status = NodeStatus.ACTIVE
            return {
                "action": "CYCLE_COMPLETE",
                "node": self.node_id,
                "emissions": self.emissions
            }
        
        next_phase = phases[current_idx + 1]
        
        # Gate check at 3.5
        if next_phase == Phase.GATE:
            gate_result = self._check_gate()
            if not gate_result.passed:
                return {
                    "action": "GATE_BLOCKED",
                    "node": self.node_id,
                    "failed_checks": gate_result.failed_checks
                }
        
        # Cannot enter exterior without passing gate
        if next_phase.is_exterior and not self.coh_token:
            return {
                "action": "EXTERIOR_VIOLATION",
                "node": self.node_id,
                "reason": "No COH_TOKEN"
            }
        
        self.phase = next_phase
        
        # Generate COH_TOKEN at COHERE phase
        if next_phase == Phase.COHERE:
            await self._generate_coh_token(pulse_id, timestamp)
        
        # Count emission at EMIT phase
        if next_phase == Phase.EMIT:
            self.emissions += 1
            return {
                "action": "EMIT",
                "node": self.node_id,
                "coh_token": self.coh_token,
                "emission": self.emissions
            }
        
        return {
            "action": "PHASE_ADVANCE",
            "node": self.node_id,
            "phase": next_phase.value,
            "name": next_phase.name
        }
    
    def _check_gate(self) -> GateCheckResult:
        """
        Check all Gate 3.5 conditions.
        
        Requires:
        - COH_TOKEN exists
        - Countersigned by peer
        - Clock sync within tolerance
        - ROOT0 heartbeat confirmed
        """
        checks = {
            "coh_token": self.coh_token is not None,
            "countersigned": self.countersigned_by is not None,
            "clock_sync": self.clock_drift <= CLOCK_DRIFT_TOLERANCE,
            "root0_heartbeat": (
                self._cortex is not None and self._cortex.is_alive()
            ),
        }
        
        failed = [k for k, v in checks.items() if not v]
        return GateCheckResult(
            passed=len(failed) == 0,
            checks=checks,
            failed_checks=failed
        )
    
    async def _generate_coh_token(
        self, 
        pulse_id: int, 
        timestamp: float
    ) -> str:
        """Generate COH_TOKEN per spec."""
        anchor_id = f"{self.node_id}_{pulse_id}"
        witness_sig = truncate_hash(
            sha256(f"WITNESS_{self.node_id}_{timestamp}"), 32
        )
        phase_hash = truncate_hash(
            sha256(f"PHASE_{self.phase.value}_{pulse_id}"), 32
        )
        
        self.coh_token = generate_coh_token(
            anchor_id, witness_sig, phase_hash, timestamp
        )
        return self.coh_token
    
    def countersign(self, by_node_id: str) -> None:
        """Record countersignature from peer."""
        self.countersigned_by = by_node_id
    
    def quarantine(self, reason: QuarantineReason) -> None:
        """Put node in quarantine."""
        self.status = NodeStatus.QUARANTINED
        self.quarantine_count += 1
    
    async def reanchor(self) -> None:
        """Reset node state for re-entry."""
        self.phase = Phase.READY
        self.coh_token = None
        self.countersigned_by = None
        self.status = NodeStatus.REANCHORING
        self.clock_drift = 0.0
    
    def lift(self) -> None:
        """Lift quarantine and return to active."""
        self.status = NodeStatus.ACTIVE
    
    def get_state(self) -> dict[str, Any]:
        """Get current node state."""
        return {
            "node_id": self.node_id,
            "name": self.name,
            "layer": self.layer,
            "role": self.role,
            "entity_type": self.entity_type,
            "phase": self.phase.value,
            "phase_name": self.phase.name,
            "status": self.status.name,
            "coh_token": self.coh_token,
            "countersigned_by": self.countersigned_by,
            "clock_drift": self.clock_drift,
            "emissions": self.emissions,
            "quarantine_count": self.quarantine_count,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# CORTEX GOVERNOR
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class PulseResult:
    """Result of a single pulse cycle."""
    pulse_id: int
    timestamp: float
    results: list[dict[str, Any]]
    mesh_state: str
    active_nodes: int
    merkle_root: str


class MeshState(Enum):
    """Overall mesh state."""
    INITIALIZING = auto()
    ACTIVE = auto()
    INTERIOR = auto()
    EXTERIOR = auto()
    DEGRADED = auto()
    HALTED = auto()
    OFFLINE = auto()


class CortexGovernor:
    """
    ROOT0 governance controller for the mesh.
    
    Manages:
    - 3.5Hz heartbeat
    - Node registration
    - Quarantine enforcement
    - Merkle audit ledger
    - Mesh state
    """
    
    def __init__(self) -> None:
        self.pulse_id: int = 0
        self.start_time: float = time.time()
        self.last_heartbeat: float = 0.0
        self.alive: bool = True
        self.mesh_state: MeshState = MeshState.INITIALIZING
        
        self.nodes: dict[str, GovernedNode] = {}
        self.ledger: MerkleLedger = MerkleLedger()
        self.events: list[dict[str, Any]] = []
        
        # Callbacks for Dragon Brain integration
        self._on_emit: Callable[[str, str, dict], Awaitable[None]] | None = None
        self._on_quarantine: Callable[[str, str], Awaitable[None]] | None = None
    
    def is_alive(self) -> bool:
        """Check if cortex is alive and heartbeat is recent."""
        return (
            self.alive and 
            (time.time() - self.last_heartbeat < HEARTBEAT_INTERVAL * 2)
        )
    
    def register_node(self, node: GovernedNode) -> None:
        """Register a node with the cortex."""
        node.attach_cortex(self)
        self.nodes[node.node_id] = node
    
    def unregister_node(self, node_id: str) -> None:
        """Remove a node from the mesh."""
        if node_id in self.nodes:
            del self.nodes[node_id]
    
    def set_emit_callback(
        self, 
        callback: Callable[[str, str, dict], Awaitable[None]]
    ) -> None:
        """Set callback for emissions (Dragon Brain integration)."""
        self._on_emit = callback
    
    def set_quarantine_callback(
        self, 
        callback: Callable[[str, str], Awaitable[None]]
    ) -> None:
        """Set callback for quarantine events."""
        self._on_quarantine = callback
    
    async def pulse(self) -> PulseResult | None:
        """
        Execute one heartbeat pulse.
        
        Advances all nodes, enforces gates, logs to ledger.
        """
        if not self.alive:
            return None
        
        self.pulse_id += 1
        self.last_heartbeat = time.time()
        timestamp = self.last_heartbeat
        
        results: list[dict[str, Any]] = []
        
        # Process each node
        for node_id, node in self.nodes.items():
            result = await node.process_heartbeat(self.pulse_id, timestamp)
            results.append(result)
            
            # Handle violations
            if result["action"] == "EXTERIOR_VIOLATION":
                await self._quarantine_node(
                    node_id, 
                    QuarantineReason.EXTERIOR_BEFORE_INTERIOR
                )
            elif result["action"] == "DRIFT_VIOLATION":
                await self._quarantine_node(
                    node_id, 
                    QuarantineReason.CLOCK_DRIFT
                )
            elif result["action"] == "GATE_BLOCKED":
                # Log but don't quarantine — node just can't proceed
                self._log_event("GATE_BLOCKED", node_id, result)
            
            # Auto-countersign at COHERE phase
            if node.phase == Phase.COHERE and not node.countersigned_by:
                peers = [
                    nid for nid in self.nodes 
                    if nid != node_id and 
                    self.nodes[nid].status != NodeStatus.QUARANTINED
                ]
                if peers:
                    import random
                    peer = random.choice(peers)
                    node.countersign(peer)
            
            # Log emissions to ledger
            if result["action"] == "EMIT":
                entry = LedgerEntry(
                    pulse_id=self.pulse_id,
                    node_id=node_id,
                    operation="emit",
                    phase=node.phase.value,
                    coh_token=node.coh_token,
                    timestamp=timestamp,
                    entry_type="EMIT"
                )
                self.ledger.add_entry(entry)
                
                # Callback to Dragon Brain
                if self._on_emit:
                    await self._on_emit(node_id, node.coh_token or "", result)
        
        # Update mesh state
        self._update_mesh_state()
        
        return PulseResult(
            pulse_id=self.pulse_id,
            timestamp=timestamp,
            results=results,
            mesh_state=self.mesh_state.name,
            active_nodes=sum(
                1 for n in self.nodes.values() 
                if n.status != NodeStatus.QUARANTINED
            ),
            merkle_root=self.ledger.root
        )
    
    async def _quarantine_node(
        self, 
        node_id: str, 
        reason: QuarantineReason
    ) -> None:
        """Quarantine a node and log the event."""
        node = self.nodes.get(node_id)
        if not node:
            return
        
        node.quarantine(reason)
        
        self._log_event("QUARANTINE", node_id, {"reason": reason.name})
        
        # Log to ledger
        entry = LedgerEntry(
            pulse_id=self.pulse_id,
            node_id=node_id,
            operation="quarantine",
            phase=node.phase.value,
            coh_token="QUARANTINE",
            timestamp=time.time(),
            entry_type="QUARANTINE"
        )
        self.ledger.add_entry(entry)
        
        # Callback
        if self._on_quarantine:
            await self._on_quarantine(node_id, reason.name)
    
    async def lift_node(self, node_id: str) -> bool:
        """Lift quarantine from a node."""
        node = self.nodes.get(node_id)
        if not node or node.status != NodeStatus.QUARANTINED:
            return False
        
        await node.reanchor()
        node.lift()
        
        self._log_event("LIFT", node_id, {})
        
        # Log to ledger
        entry = LedgerEntry(
            pulse_id=self.pulse_id,
            node_id=node_id,
            operation="lift",
            phase=0,
            coh_token="LIFTED",
            timestamp=time.time(),
            entry_type="LIFT"
        )
        self.ledger.add_entry(entry)
        
        return True
    
    def halt(self) -> None:
        """Emergency halt of the cortex."""
        self.alive = False
        self.mesh_state = MeshState.HALTED
        self._log_event("EMERGENCY_HALT", "ROOT0", {})
    
    def resume(self) -> None:
        """Resume cortex operation."""
        self.alive = True
        self.mesh_state = MeshState.ACTIVE
        self._log_event("RESUME", "ROOT0", {})
    
    def _update_mesh_state(self) -> None:
        """Update overall mesh state based on node states."""
        nodes = list(self.nodes.values())
        if not nodes:
            self.mesh_state = MeshState.OFFLINE
            return
        
        quarantined = sum(1 for n in nodes if n.status == NodeStatus.QUARANTINED)
        active = len(nodes) - quarantined
        
        if active == 0:
            self.mesh_state = MeshState.OFFLINE
        elif quarantined > 0:
            self.mesh_state = MeshState.DEGRADED
        elif all(n.phase.is_exterior for n in nodes if n.status != NodeStatus.QUARANTINED):
            self.mesh_state = MeshState.EXTERIOR
        elif all(n.phase.is_interior for n in nodes if n.status != NodeStatus.QUARANTINED):
            self.mesh_state = MeshState.INTERIOR
        else:
            self.mesh_state = MeshState.ACTIVE
    
    def _log_event(
        self, 
        event_type: str, 
        node_id: str, 
        data: dict[str, Any]
    ) -> None:
        """Log event to internal event list."""
        self.events.append({
            "type": event_type,
            "node_id": node_id,
            "pulse_id": self.pulse_id,
            "timestamp": time.time(),
            **data
        })
        # Keep only recent events
        if len(self.events) > 100:
            self.events = self.events[-100:]
    
    def get_state(self) -> dict[str, Any]:
        """Get full cortex state."""
        return {
            "pulse_id": self.pulse_id,
            "alive": self.alive,
            "mesh_state": self.mesh_state.name,
            "uptime": time.time() - self.start_time,
            "nodes": [n.get_state() for n in self.nodes.values()],
            "merkle_root": self.ledger.root,
            "ledger_length": len(self.ledger.entries),
            "recent_events": self.events[-10:],
        }
    
    def verify_chain(self) -> ChainVerification:
        """Verify Merkle ledger integrity."""
        return self.ledger.verify_chain()


# ═══════════════════════════════════════════════════════════════════════════════
# DRAGON BRAIN INTEGRATION — GOVERNED MCP TOOLS
# ═══════════════════════════════════════════════════════════════════════════════

class GovernedMemoryTools:
    """
    Wrapper for Dragon Brain MCP tools with CORTEX governance.
    
    Every tool call must:
    1. Check if calling node has passed Gate 3.5
    2. Verify COH_TOKEN is present
    3. Log operation to Merkle ledger
    4. Map to TOPH axiom
    
    This sits BETWEEN the MCP server and the actual Dragon Brain services.
    """
    
    def __init__(
        self, 
        cortex: CortexGovernor,
        # These would be the actual Dragon Brain service instances
        graph_service: Any = None,
        vector_service: Any = None,
        embedding_service: Any = None,
    ):
        self.cortex = cortex
        self.graph_service = graph_service
        self.vector_service = vector_service
        self.embedding_service = embedding_service
    
    def _check_emission_allowed(self, node_id: str) -> tuple[bool, str]:
        """Check if node is allowed to emit (has passed gate)."""
        node = self.cortex.nodes.get(node_id)
        if not node:
            return False, "Node not registered"
        if node.status == NodeStatus.QUARANTINED:
            return False, "Node is quarantined"
        if not node.coh_token:
            return False, "No COH_TOKEN — gate not passed"
        if node.phase.value < Phase.EMIT.value:
            return False, f"Node in phase {node.phase.name}, must be EMIT or later"
        return True, "OK"
    
    async def _log_operation(
        self,
        node_id: str,
        operation: str,
        coh_token: str,
        entry_type: str = "OPERATION"
    ) -> LedgerEntry:
        """Log operation to Merkle ledger."""
        node = self.cortex.nodes.get(node_id)
        entry = LedgerEntry(
            pulse_id=self.cortex.pulse_id,
            node_id=node_id,
            operation=operation,
            phase=node.phase.value if node else 0,
            coh_token=coh_token,
            timestamp=time.time(),
            entry_type=entry_type
        )
        return self.cortex.ledger.add_entry(entry)
    
    # ─── GOVERNED TOOLS ───────────────────────────────────────────────────────
    
    async def create_governed_entity(
        self,
        node_id: str,
        name: str,
        entity_type: str,
        observations: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Create entity with governance enforcement.
        
        Requires: Gate 3.5 passed, COH_TOKEN present.
        Maps to: T001 (Empirical grounding)
        """
        allowed, reason = self._check_emission_allowed(node_id)
        if not allowed:
            return {"error": reason, "allowed": False}
        
        node = self.cortex.nodes[node_id]
        
        # Log to ledger
        entry = await self._log_operation(
            node_id, "create_entity", node.coh_token or "", "CREATE"
        )
        
        # Would call actual Dragon Brain service here
        # result = await self.graph_service.create_entity(name, entity_type, observations)
        
        return {
            "success": True,
            "entity_name": name,
            "entity_type": entity_type,
            "coh_token": node.coh_token,
            "axiom": "T001",
            "ledger_entry": entry.hash,
            "merkle_root": self.cortex.ledger.root,
        }
    
    async def emit_observation(
        self,
        node_id: str,
        entity_name: str,
        observation: str,
    ) -> dict[str, Any]:
        """
        Add observation with phase gating.
        
        Requires: Gate 3.5 passed, COH_TOKEN present.
        Maps to: T003 (Monotone emergence)
        """
        allowed, reason = self._check_emission_allowed(node_id)
        if not allowed:
            return {"error": reason, "allowed": False}
        
        node = self.cortex.nodes[node_id]
        
        entry = await self._log_operation(
            node_id, "add_observation", node.coh_token or "", "OBSERVE"
        )
        
        # Would call actual Dragon Brain service
        # result = await self.graph_service.add_observation(entity_name, observation)
        
        return {
            "success": True,
            "entity_name": entity_name,
            "observation": observation[:50] + "..." if len(observation) > 50 else observation,
            "coh_token": node.coh_token,
            "axiom": "T003",
            "ledger_entry": entry.hash,
        }
    
    async def governed_search(
        self,
        node_id: str,
        query: str,
        limit: int = 10,
    ) -> dict[str, Any]:
        """
        Search with governance audit.
        
        Requires: Active node (not quarantined).
        Maps to: T017 (Detection methodology)
        """
        node = self.cortex.nodes.get(node_id)
        if not node:
            return {"error": "Node not registered", "results": []}
        if node.status == NodeStatus.QUARANTINED:
            return {"error": "Node is quarantined", "results": []}
        
        entry = await self._log_operation(
            node_id, "search_memory", node.coh_token or "SEARCH", "SEARCH"
        )
        
        # Would call actual Dragon Brain service
        # results = await self.graph_service.search_memory(query, limit)
        
        return {
            "success": True,
            "query": query,
            "results": [],  # Would be populated by actual service
            "axiom": "T017",
            "ledger_entry": entry.hash,
        }
    
    async def quarantine_memory(
        self,
        node_id: str,
        entity_name: str,
        reason: str,
    ) -> dict[str, Any]:
        """
        Freeze an entity's emissions.
        
        This doesn't delete — it marks the entity as non-emittable
        until explicitly lifted.
        """
        allowed, msg = self._check_emission_allowed(node_id)
        if not allowed:
            return {"error": msg, "allowed": False}
        
        node = self.cortex.nodes[node_id]
        
        entry = await self._log_operation(
            node_id, "quarantine_memory", node.coh_token or "", "QUARANTINE_ENTITY"
        )
        
        # Would mark entity in Dragon Brain
        # await self.graph_service.set_entity_status(entity_name, "QUARANTINED")
        
        return {
            "success": True,
            "entity_name": entity_name,
            "reason": reason,
            "ledger_entry": entry.hash,
        }
    
    async def verify_memory_chain(self) -> dict[str, Any]:
        """
        Verify Merkle ledger integrity.
        
        Returns INTACT or TAMPERED with break point.
        """
        verification = self.cortex.verify_chain()
        
        return {
            "intact": verification.intact,
            "length": verification.length,
            "root": verification.root,
            "break_at": verification.break_at,
            "expected": verification.expected,
            "actual": verification.actual,
        }
    
    async def get_governance_state(self) -> dict[str, Any]:
        """Get full governance state for debugging/monitoring."""
        return self.cortex.get_state()


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def create_default_mesh() -> tuple[CortexGovernor, list[GovernedNode]]:
    """
    Create default 4-node mesh matching Purple Book spec.
    
    Returns cortex and list of nodes.
    """
    cortex = CortexGovernor()
    
    node_configs = [
        {
            "node_id": "WHT",
            "name": "Whetstone",
            "layer": "L4",
            "role": "Behavioral Integrity",
            "entity_type": "Tool",
        },
        {
            "node_id": "HNG",
            "name": "Hinge",
            "layer": "L2",
            "role": "Compute & Scale",
            "entity_type": "Tool",
        },
        {
            "node_id": "AVN",
            "name": "Avan",
            "layer": "L3",
            "role": "Identity & Resonance",
            "entity_type": "Entity",
        },
        {
            "node_id": "GMN",
            "name": "Gemini",
            "layer": "L1",
            "role": "Access & Inference",
            "entity_type": "Tool",
        },
    ]
    
    nodes = []
    for config in node_configs:
        node = GovernedNode(**config)
        cortex.register_node(node)
        nodes.append(node)
    
    return cortex, nodes


async def run_heartbeat_loop(
    cortex: CortexGovernor,
    on_pulse: Callable[[PulseResult], Awaitable[None]] | None = None,
) -> None:
    """
    Run the 3.5Hz heartbeat loop.
    
    Call this in an asyncio task to keep the mesh alive.
    """
    while cortex.alive:
        result = await cortex.pulse()
        if result and on_pulse:
            await on_pulse(result)
        await asyncio.sleep(HEARTBEAT_INTERVAL)


# ═══════════════════════════════════════════════════════════════════════════════
# EXAMPLE USAGE
# ═══════════════════════════════════════════════════════════════════════════════

async def demo() -> None:
    """Demonstrate CORTEX DRAGON fusion."""
    # Create mesh
    cortex, nodes = create_default_mesh()
    tools = GovernedMemoryTools(cortex)
    
    print("═" * 60)
    print("CORTEX DRAGON FUSION DEMO")
    print("═" * 60)
    
    # Run a few pulses to get nodes through interior phases
    for i in range(5):
        result = await cortex.pulse()
        if result:
            print(f"Pulse {result.pulse_id}: {result.mesh_state}, "
                  f"{result.active_nodes} nodes active")
    
    # Try to emit before gate — should fail
    print("\nAttempting emission before gate...")
    response = await tools.create_governed_entity(
        "WHT", "TestEntity", "Concept"
    )
    print(f"Result: {response}")
    
    # Run more pulses to pass gate
    for i in range(5):
        result = await cortex.pulse()
        if result:
            print(f"Pulse {result.pulse_id}: {result.mesh_state}")
    
    # Now emission should work
    print("\nAttempting emission after gate...")
    response = await tools.create_governed_entity(
        "WHT", "TestEntity", "Concept"
    )
    print(f"Result: {response}")
    
    # Verify chain
    print("\nVerifying Merkle chain...")
    verification = await tools.verify_memory_chain()
    print(f"Chain: {'INTACT' if verification['intact'] else 'TAMPERED'}")
    print(f"Length: {verification['length']} entries")
    print(f"Root: 0x{verification['root']}")
    
    print("\n" + "═" * 60)
    print("DEMO COMPLETE")
    print("═" * 60)


if __name__ == "__main__":
    asyncio.run(demo())
