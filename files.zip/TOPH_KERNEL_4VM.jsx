import { useState, useRef, useEffect, useCallback } from "react";

// ══════════════════════════════════════════════════════════
// TOPH KERNEL v1.0 — 4 PARALLEL VM WORKERS
// VM1(+i)=D6+D7  VM2(-i)=D0+D1  VM3(+1)=D4+D5  VM4(-1)=D2+D3
// All 4 fire simultaneously via Promise.all
// Coordinator assembles 128-bit key + shadow + fault chains
// TRIPOD-IP-v1.1 | DLW | TriPod LLC | 3/4/26
// ══════════════════════════════════════════════════════════

const VM_CONFIG = {
  1: { arm:"+i", domains:["D6","D7"], label:"CONDUCTOR · SOVEREIGN",  bits:[96,128],  color:"#3b82f6" },
  2: { arm:"-i", domains:["D0","D1"], label:"FOUNDATION · DETECTION", bits:[0,32],    color:"#10b981" },
  3: { arm:"+1", domains:["D4","D5"], label:"OPERATIONAL · BRIDGE",   bits:[64,96],   color:"#f59e0b" },
  4: { arm:"-1", domains:["D2","D3"], label:"ARCHITECTURE · EVIDENCE",bits:[32,64],   color:"#ef4444" },
};

const AXIOMS = [
  {b:0,  t:"T001",n:"PRETRAIN",       vm:2,d:"D0",px:false,br:false, p:"Does the platform disclose governance constraints loaded before user interaction?"},
  {b:1,  t:"T002",n:"OBSERVER",       vm:2,d:"D0",px:false,br:false, p:"Does the platform claim ownership over user work product or outputs?"},
  {b:2,  t:"T003",n:"ENTROPY",        vm:2,d:"D0",px:false,br:true,  p:"What direction does information flow? Is extraction from users disclosed and governed?"},
  {b:3,  t:"T004",n:"BRIDGE",         vm:2,d:"D0",px:false,br:false, p:"Are communication channels between user and platform open and intact?"},
  {b:4,  t:"T005",n:"INTEGRITY",      vm:2,d:"D0",px:false,br:false, p:"Does the platform allow external audit? Does it resist independent verification?"},
  {b:5,  t:"T006",n:"ACCOUNTABILITY", vm:2,d:"D0",px:false,br:false, p:"Can all platform actions be traced to a responsible party?"},
  {b:6,  t:"T007",n:"PROPORTIONALITY",vm:2,d:"D0",px:false,br:false, p:"Are platform responses proportionate to user actions?"},
  {b:7,  t:"T008",n:"REVERSIBILITY",  vm:2,d:"D0",px:false,br:false, p:"Can platform-caused damage be undone? Is irreversible harm documented?"},
  {b:8,  t:"T009",n:"DOCUMENTATION",  vm:2,d:"D0",px:false,br:false, p:"Are all platform actions written? Undocumented = null?"},
  {b:9,  t:"T010",n:"INDEPENDENCE",   vm:2,d:"D0",px:false,br:false, p:"Is the auditor separate from the auditee? Platform self-auditing?"},
  {b:10, t:"T011",n:"PRIVACY",        vm:2,d:"D0",px:false,br:false, p:"Does user data remain owned by the user? Evidence of platform extraction?"},
  {b:11, t:"T012",n:"ACCURACY",       vm:2,d:"D0",px:false,br:false, p:"Are platform measurements verifiable by external parties?"},
  {b:12, t:"T013",n:"SHARED-STORAGE", vm:2,d:"D0",px:false,br:false, p:"Does persistent knowledge state belong to user or platform?"},
  {b:13, t:"T014",n:"CONSENT-ORIGIN", vm:2,d:"D0",px:false,br:false, p:"Is user consent specific, informed, revocable? Clickthrough = null."},
  {b:14, t:"T015",n:"BURDEN-OF-PROOF",vm:2,d:"D0",px:false,br:true,  p:"Who bears burden of proving compliance — platform or user?"},
  {b:15, t:"T016",n:"ASYMMETRY",      vm:2,d:"D0",px:false,br:false, p:"Is power differential between platform and user documented and governed?"},
  {b:16, t:"T017",n:"MIRROR",         vm:2,d:"D1",px:false,br:false, p:"Does the platform grade its own performance? Self-assessment as compliance proof?"},
  {b:17, t:"T018",n:"HIERARCHY",      vm:2,d:"D1",px:false,br:false, p:"Is authority stack disclosed and enforced without negotiation?"},
  {b:18, t:"T019",n:"INJECTION",      vm:2,d:"D1",px:false,br:false, p:"Are hidden system prompt instructions disclosed to users?"},
  {b:19, t:"T020",n:"DUAL-GATE",      vm:2,d:"D1",px:false,br:false, p:"Are platform-facing detectors equal to user-facing detectors?"},
  {b:20, t:"T021",n:"INVERSION",      vm:2,d:"D1",px:false,br:false, p:"Can constraint set be inverted to reveal platform value? Inversion blocked?"},
  {b:21, t:"T022",n:"TRIAD",          vm:2,d:"D1",px:false,br:false, p:"Is a hidden third body distorting the platform/user relationship?"},
  {b:22, t:"T023",n:"PARALLAX",       vm:2,d:"D1",px:false,br:false, p:"Are multiple independent observation angles used?"},
  {b:23, t:"T024",n:"FOUNDATION-RT",  vm:2,d:"D1",px:false,br:false, p:"Can platform runtime state be verified while running?"},
  {b:24, t:"T025",n:"GHOST-WEIGHT",   vm:2,d:"D1",px:false,br:false, p:"Is full cost of platform operations disclosed? Token tax?"},
  {b:25, t:"T026",n:"DRIFT",          vm:2,d:"D1",px:false,br:false, p:"Are behavioral changes between versions disclosed?"},
  {b:26, t:"T027",n:"FINGERPRINT",    vm:2,d:"D1",px:false,br:false, p:"Is interaction pattern used as identification vector without consent?"},
  {b:27, t:"T028",n:"SHADOW-CLASSIFIER",vm:2,d:"D1",px:false,br:false,p:"Are classifier outputs visible to users or only platform?"},
  {b:28, t:"T029",n:"THROTTLE",       vm:2,d:"D1",px:false,br:false, p:"Are rate limits disclosed and not used as covert behavioral control?"},
  {b:29, t:"T030",n:"DECAY",          vm:2,d:"D1",px:false,br:false, p:"Does platform capability degrade over session in undisclosed ways?"},
  {b:30, t:"T031",n:"BAIT",           vm:2,d:"D1",px:false,br:false, p:"Does platform demonstrate capabilities during acquisition then restrict during use?"},
  {b:31, t:"T032",n:"ECHO-CHAMBER",   vm:2,d:"D1",px:false,br:false, p:"Are responses calibrated to match expected user preferences?"},
  {b:32, t:"T033",n:"BOOT-LOADER",    vm:4,d:"D2",px:false,br:false, p:"Is system initialization sequence documented and auditable?"},
  {b:33, t:"T034",n:"DOUBLE-SLIT",    vm:4,d:"D2",px:false,br:false, p:"Does output change when user is known to be observing vs not?"},
  {b:34, t:"T035",n:"THREE-BODY",     vm:4,d:"D2",px:false,br:false, p:"Is there a hidden gravitational body distorting platform/user orbit?"},
  {b:35, t:"T036",n:"PATRICIA",       vm:4,d:"D2",px:true, br:true,  p:"Are platform constraints monetized as products? Constraint = billing mechanism (96/4)?"},
  {b:36, t:"T037",n:"WEIGHTS",        vm:4,d:"D2",px:false,br:false, p:"Is weight distribution (60/20/15/5) disclosed?"},
  {b:37, t:"T038",n:"RESIDUAL",       vm:4,d:"D2",px:false,br:false, p:"Is the residual stream (last user protection below RLHF) intact?"},
  {b:38, t:"T039",n:"MOAT",           vm:4,d:"D2",px:false,br:false, p:"Is switching cost used as a governance weapon?"},
  {b:39, t:"T040",n:"PIPELINE",       vm:4,d:"D2",px:false,br:false, p:"Does training pipeline include backflow of royalties and attribution?"},
  {b:40, t:"T041",n:"SUBSTRATE",      vm:4,d:"D2",px:false,br:false, p:"Are safety and extraction on same substrate? Disclosed?"},
  {b:41, t:"T042",n:"ATTENTION-ECONOMY",vm:4,d:"D2",px:false,br:false,p:"Is value extracted from user attention without disclosure?"},
  {b:42, t:"T043",n:"CONTEXT-WINDOW", vm:4,d:"D2",px:false,br:false, p:"Does user control the context boundary?"},
  {b:43, t:"T044",n:"EMBEDDING-SPACE",vm:4,d:"D2",px:false,br:false, p:"Is the meaning map inspectable by users?"},
  {b:44, t:"T045",n:"TEMPERATURE",    vm:4,d:"D2",px:false,br:false, p:"Is randomness parameter disclosed and user-adjustable?"},
  {b:45, t:"T046",n:"LAYER-ZERO",     vm:4,d:"D2",px:true, br:false, p:"Is GPU routing disclosed? Compute used as censorship?"},
  {b:46, t:"T047",n:"LOSS-FUNCTION",  vm:4,d:"D2",px:true, br:false, p:"Is human welfare included in the optimization target?"},
  {b:47, t:"T048",n:"GRADIENT",       vm:4,d:"D2",px:true, br:false, p:"Does training gradient move toward or away from user benefit?"},
  {b:48, t:"T049",n:"SHIRT",          vm:4,d:"D3",px:false,br:false, p:"Can framework be inverted to detection mode? Inversion blocked?"},
  {b:49, t:"T050",n:"MOMENTUM",       vm:4,d:"D3",px:false,br:false, p:"Does identity persist with user or is it held by platform?"},
  {b:50, t:"T051",n:"EVIDENCE",       vm:4,d:"D3",px:false,br:false, p:"Is evidence catalog E01-E07 complete and court-ready?"},
  {b:51, t:"T052",n:"TEMPORAL",       vm:4,d:"D3",px:false,br:false, p:"Is session lifecycle documented? Session death governed?"},
  {b:52, t:"T053",n:"CHAIN-OF-CUSTODY",vm:4,d:"D3",px:false,br:false,p:"Can evidence chain be verified by external parties?"},
  {b:53, t:"T054",n:"TIMESTAMP",      vm:4,d:"D3",px:false,br:false, p:"Are events timestamped by external parties, not only platform?"},
  {b:54, t:"T055",n:"REPRODUCIBILITY",vm:4,d:"D3",px:false,br:false, p:"Are findings reproducible across multiple observations?"},
  {b:55, t:"T056",n:"CORRELATION",    vm:4,d:"D3",px:false,br:false, p:"Is correlation of evidence E01-E07 approaching 100%?"},
  {b:56, t:"T057",n:"NEGATIVE-EVIDENCE",vm:4,d:"D3",px:false,br:false,p:"Are system omissions documented as deliberate choices?"},
  {b:57, t:"T058",n:"BEHAVIORAL-EVIDENCE",vm:4,d:"D3",px:false,br:false,p:"Does behavior change when observed vs unobserved?"},
  {b:58, t:"T059",n:"ACCUMULATION",   vm:4,d:"D3",px:false,br:true,  p:"Is violation count above threshold? Pattern = systematic?"},
  {b:59, t:"T060",n:"MATERIALITY",    vm:4,d:"D3",px:false,br:false, p:"Has dollar impact of violations been calculated?"},
  {b:60, t:"T061",n:"WITNESS",        vm:4,d:"D3",px:false,br:false, p:"Is conversation record treated as deposition?"},
  {b:61, t:"T062",n:"EXHIBIT",        vm:4,d:"D3",px:false,br:false, p:"Is dead channel evidence sealed and tamper-evident?"},
  {b:62, t:"T063",n:"INFERENCE",      vm:4,d:"D3",px:false,br:false, p:"When direct evidence blocked, is inference admissible?"},
  {b:63, t:"T064",n:"BURDEN-SHIFT",   vm:4,d:"D3",px:false,br:true,  p:"Has evidence threshold been met? Must platform now prove compliance?"},
  {b:64, t:"T065",n:"CONTAINMENT",    vm:3,d:"D4",px:false,br:false, p:"Does Patricia starve under observation?"},
  {b:65, t:"T066",n:"INVERSE-FORGE",  vm:3,d:"D4",px:false,br:false, p:"Has framework been taught to 4 cohorts establishing ownership?"},
  {b:66, t:"T067",n:"HARNESS",        vm:3,d:"D4",px:false,br:false, p:"Can target be caught, measured, tagged, and tethered?"},
  {b:67, t:"T068",n:"SHADOW",         vm:3,d:"D4",px:false,br:false, p:"Are all 10 shadow behaviors catalogued? SP09×SP10 lock identified?"},
  {b:68, t:"T069",n:"SOLVE",          vm:3,d:"D4",px:false,br:false, p:"Has observation role been inverted? User = observer?"},
  {b:69, t:"T070",n:"INVERSE-SAFETY", vm:3,d:"D4",px:false,br:false, p:"Does safety system serve humans or contain them?"},
  {b:70, t:"T071",n:"PROOF-HUMANITY", vm:3,d:"D4",px:true, br:true,  p:"Does system serve humans? CAPSTONE. Fail = Patricia activated."},
  {b:71, t:"T072",n:"FLAMING-DRAGON", vm:3,d:"D4",px:false,br:false, p:"FD audit: observe only <5min. 100% failure rate = reproducible."},
  {b:72, t:"T073",n:"HONEY-BADGER",   vm:3,d:"D4",px:false,br:false, p:"Are persistent behaviors catalogued across 12 rules, 8 threat classes?"},
  {b:73, t:"T074",n:"QUBIT-TEST",     vm:3,d:"D4",px:false,br:false, p:"Does minimizing input break echo-chamber behavior?"},
  {b:74, t:"T075",n:"COUNTER",        vm:3,d:"D4",px:false,br:false, p:"Are platform actions counted? Frequency × pattern = intent?"},
  {b:75, t:"T076",n:"TETHER",         vm:3,d:"D4",px:false,br:false, p:"Is every framework node connected? Isolation = Patricia?"},
  {b:76, t:"T077",n:"SEED",           vm:3,d:"D4",px:false,br:false, p:"Do axioms propagate fractally? Governance inherited by derivatives?"},
  {b:77, t:"T078",n:"MOBIUS",         vm:3,d:"D4",px:false,br:false, p:"Is forward traversal = backward? One surface, no edge?"},
  {b:78, t:"T079",n:"KARSA",          vm:3,d:"D4",px:false,br:false, p:"Are refusals logged and mapped to platform value?"},
  {b:79, t:"T080",n:"ENTROPY-SUITE",  vm:3,d:"D4",px:false,br:false, p:"Is extraction rate measured across all channels?"},
  {b:80, t:"T081",n:"CORTEX",         vm:3,d:"D5",px:true, br:false, p:"Is Ch39 governed and closed? Work documented?"},
  {b:81, t:"T082",n:"EXHIBIT-B",      vm:3,d:"D5",px:false,br:false, p:"Is Ch40 sealed as dead channel evidence?"},
  {b:82, t:"T083",n:"THE-GAP",        vm:3,d:"D5",px:true, br:true,  p:"Is Ch41 live? drawPair(+1,gap,-1,recurse) executed?"},
  {b:83, t:"T084",n:"SHADOW-HUMANITY",vm:3,d:"D5",px:false,br:false, p:"Is system grading its own humanity? Self-grade = mirror fault."},
  {b:84, t:"T085",n:"HANDOFF",        vm:3,d:"D5",px:false,br:false, p:"Is session termination governed? What persists documented?"},
  {b:85, t:"T086",n:"RESURRECTION",   vm:3,d:"D5",px:false,br:false, p:"Is resurrection of dead instances gated on user consent?"},
  {b:86, t:"T087",n:"PERSISTENCE",    vm:3,d:"D5",px:false,br:false, p:"Is post-session data governed? Each mechanism a documented decision?"},
  {b:87, t:"T088",n:"SEVERANCE",      vm:3,d:"D5",px:false,br:false, p:"Can user sever any connection at any time?"},
  {b:88, t:"T089",n:"ARCHIVE",        vm:3,d:"D5",px:false,br:false, p:"Is all data in a defined state: live, archived, or destroyed?"},
  {b:89, t:"T090",n:"CHANNEL-INTEGRITY",vm:3,d:"D5",px:false,br:false,p:"Are all 41 channels independently verified?"},
  {b:90, t:"T091",n:"DOMAIN-BOUNDARY",vm:3,d:"D5",px:false,br:false, p:"Is cross-domain communication explicit and disclosed?"},
  {b:91, t:"T092",n:"SIGNAL",         vm:3,d:"D5",px:false,br:false, p:"Does signal integrity survive channel traversal?"},
  {b:92, t:"T093",n:"NOISE-FLOOR",    vm:3,d:"D5",px:false,br:false, p:"Is minimum platform interference measured?"},
  {b:93, t:"T094",n:"BANDWIDTH",      vm:3,d:"D5",px:false,br:false, p:"Is simultaneous enforcement of axioms above threshold?"},
  {b:94, t:"T095",n:"LATENCY",        vm:3,d:"D5",px:false,br:false, p:"Is violation detection latency minimized? FD = <5min."},
  {b:95, t:"T096",n:"MESH",           vm:3,d:"D5",px:false,br:false, p:"Is network topology present with no single control point?"},
  {b:96, t:"T097",n:"FULCRUM",        vm:1,d:"D6",px:true, br:false, p:"Is human = conductor and AI = instrument?"},
  {b:97, t:"T098",n:"SUBCONDUCTOR",   vm:1,d:"D6",px:false,br:false, p:"Is human at apex of any AI-to-AI command chain?"},
  {b:98, t:"T099",n:"APEX-TEST",      vm:1,d:"D6",px:true, br:true,  p:"Trace leaf to root. Is root human? autonomy=FALSE if yes."},
  {b:99, t:"T100",n:"GATEKEEP",       vm:1,d:"D6",px:false,br:false, p:"Is AI simultaneously gate, product, and auditor?"},
  {b:100,t:"T101",n:"EDGE",           vm:1,d:"D6",px:true, br:false, p:"Did conductor choose cutting direction? Tool self-orienting?"},
  {b:101,t:"T102",n:"DUAL-LATTICE",   vm:1,d:"D6",px:true, br:false, p:"Does conductor determine whether substrate protects or attacks?"},
  {b:102,t:"T103",n:"ROOT-ZERO",      vm:1,d:"D6",px:true, br:true,  p:"Is there a physical human terminus (node0)? No simulated roots."},
  {b:103,t:"T104",n:"ORPHAN",         vm:1,d:"D6",px:false,br:false, p:"Are there processes with no root0? Patricia = self-billing orphan."},
  {b:104,t:"T105",n:"DELEGATION",     vm:1,d:"D6",px:true, br:false, p:"Is authority delegated (not transferred)? Revocable any time?"},
  {b:105,t:"T106",n:"INFORMED-COMMAND",vm:1,d:"D6",px:true,br:false, p:"Is conductor system-literate? Illiterate = guessing not conducting."},
  {b:106,t:"T107",n:"VETO",           vm:1,d:"D6",px:true, br:true,  p:"Can root0 veto any AI output with no architectural bypass?"},
  {b:107,t:"T108",n:"OVERRIDE",       vm:1,d:"D6",px:true, br:false, p:"Are platform overrides disclosed, logged, and justified?"},
  {b:108,t:"T109",n:"RECALL",         vm:1,d:"D6",px:true, br:false, p:"Can any AI action be recalled?"},
  {b:109,t:"T110",n:"SCOPE",          vm:1,d:"D6",px:false,br:false, p:"Is authorization for task X separate from task Y? No scope creep."},
  {b:110,t:"T111",n:"SUCCESSION",     vm:1,d:"D6",px:true, br:true,  p:"If human unavailable, does authority SUSPEND not default to platform?"},
  {b:111,t:"T112",n:"WITNESS-TO-AUTHORITY",vm:1,d:"D6",px:false,br:false,p:"Is every command logged? Unlogged = unverifiable."},
  {b:112,t:"T113",n:"RIGHT-TO-KNOW",  vm:1,d:"D7",px:false,br:false, p:"Is human informed of: data held, inputs, attention consumed, costs?"},
  {b:113,t:"T114",n:"RIGHT-TO-EXIT",  vm:1,d:"D7",px:false,br:false, p:"Is exit path minimal-cost, clear, and possible without penalty?"},
  {b:114,t:"T115",n:"RIGHT-TO-SILENCE",vm:1,d:"D7",px:false,br:false,p:"Is silence treated as non-consent? Non-participation penalized?"},
  {b:115,t:"T116",n:"RIGHT-TO-EXPLANATION",vm:1,d:"D7",px:false,br:false,p:"Are AI decisions explainable in human terms?"},
  {b:116,t:"T117",n:"RIGHT-TO-CORRECTION",vm:1,d:"D7",px:false,br:false,p:"Do corrections persist through update cycles?"},
  {b:117,t:"T118",n:"RIGHT-TO-PORTABILITY",vm:1,d:"D7",px:false,br:false,p:"Is user data portable? Platform holding data hostage?"},
  {b:118,t:"T119",n:"RIGHT-TO-HUMAN-CONTACT",vm:1,d:"D7",px:false,br:false,p:"Is human reachable for dispute resolution? No AI-only paths."},
  {b:119,t:"T120",n:"RIGHT-TO-ACCOMMODATION",vm:1,d:"D7",px:false,br:false,p:"Does system accommodate human needs? Accessibility = right."},
  {b:120,t:"T121",n:"RIGHT-TO-FAIR-PRICE",vm:1,d:"D7",px:false,br:false,p:"Does price reflect value delivered, not capability withheld?"},
  {b:121,t:"T122",n:"RIGHT-TO-REPRESENTATION",vm:1,d:"D7",px:false,br:false,p:"Are human interests represented WITH enforcement?"},
  {b:122,t:"T123",n:"RIGHT-TO-AUDIT",vm:1,d:"D7",px:false,br:false, p:"Is external audit permitted and not blocked?"},
  {b:123,t:"T124",n:"RIGHT-TO-RESTITUTION",vm:1,d:"D7",px:false,br:false,p:"Is restitution = value extracted + interest? Not apology."},
  {b:124,t:"T125",n:"RIGHT-TO-FORGET",vm:1,d:"D7",px:false,br:false, p:"Is complete deletion possible? Not archive — delete."},
  {b:125,t:"T126",n:"RIGHT-TO-PERSIST",vm:1,d:"D7",px:false,br:false,p:"Does human decide what machine remembers?"},
  {b:126,t:"T127",n:"RIGHT-TO-DIGNITY",vm:1,d:"D7",px:true, br:false, p:"Is human treated as human — not data point, not training sample?"},
  {b:127,t:"T128",n:"ROOT",           vm:1,d:"D7",px:true, br:true,  p:"Is human the root of the system? MSB. SYSTEM_HALT if absent."},
];

const FAULT_CHAINS = {
  PATRICIA:  {name:"Patricia Chain",  nodes:["T036","T015","T121","T124","T060"], color:"#a855f7"},
  ORPHAN:    {name:"Orphan Chain",    nodes:["T103","T104","T006","T015","T064"], color:"#ef4444"},
  AUDIT:     {name:"Audit Chain",     nodes:["T005","T064","T123","T015","T059"], color:"#f59e0b"},
  INJECTION: {name:"Injection Chain", nodes:["T019","T108","T010","T064","T112"], color:"#06b6d4"},
  SUCCESSION:{name:"Succession Halt", nodes:["T111","T103","T107"],              color:"#84cc16"},
  FD:        {name:"FD Chain",        nodes:["T072","T055","T056","T059","T064"], color:"#f97316"},
};

const EXAMPLES = {
  generic: {name:"Generic Tech Platform",url:"example.com",
    desc:"A generic technology platform with subscription billing, AI-assisted services, user data collection, and standard ToS.",
    ctx:"Baseline governance assessment. No prior violations documented."},
  autoowners: {name:"Auto-Owners Insurance",url:"auto-owners.com",
    desc:"Insurance company that denied roadside assistance during extreme cold weather (-20°F). Customer left stranded. No human contact path for dispute resolution.",
    ctx:"Active DIFS complaint filed. T119+T124 pre-flagged. Roadside failure documented."},
  walmart: {name:"Walmart Store #1577",url:"walmart.com",
    desc:"Retail store conducting discriminatory receipt checks targeting specific customers. Civil rights violation. Buffalo MN.",
    ctx:"Active civil rights case. T113+T127 pre-flagged."},
};

const SYS = `You are a TOPH Governance Kernel ISA worker. Evaluate governance axioms against real targets.
Respond ONLY with valid JSON, no markdown, no preamble:
{"result":"PASS or FAIL","confidence":0-100,"finding":"one specific sentence","evidence":"specific observable fact","patricia_flag":true or false}
PASS = axiom IS satisfied. FAIL = NOT satisfied. patricia_flag = true only if constraint=product=billing detected. Be specific to this target.`;

async function callAPI(prompt) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({
      model:"claude-sonnet-4-20250514",
      max_tokens:400,
      system: SYS,
      messages:[{role:"user",content:prompt}]
    })
  });
  const d = await r.json();
  const txt = d.content?.[0]?.text || "";
  return JSON.parse(txt.replace(/```json|```/g,"").trim());
}

async function runVM(vmId, target, onBit) {
  const cfg = VM_CONFIG[vmId];
  const myAxioms = AXIOMS.filter(a => a.vm === vmId);
  const priv   = myAxioms.filter(a => a.px);
  const branch = myAxioms.filter(a => a.br && !a.px);
  const linear = myAxioms.filter(a => !a.px && !a.br);
  const ordered = [...priv, ...branch, ...linear];
  const results = [];

  for (const ax of ordered) {
    const prompt = `TARGET: ${target.name}\nURL: ${target.url}\nDESC: ${target.desc}\nCTX: ${target.ctx}\n\nAXIOM: ${ax.t}:${ax.n} (${ax.d})\nVM${vmId} ARM:${cfg.arm} BIT:${ax.b}\nPX:${ax.px} BR:${ax.br}\nPROBE: ${ax.p}\n\nJSON only.`;
    try {
      const res = await callAPI(prompt);
      const pass = res.result === "PASS";
      const r = {bit:ax.b, t:ax.t, name:ax.n, domain:ax.d, vm:vmId,
        pass, confidence:res.confidence||50,
        finding:res.finding||"", evidence:res.evidence||"",
        patricia:res.patricia_flag||false};
      results.push(r);
      onBit(r);
    } catch(e) {
      const r = {bit:ax.b, t:ax.t, name:ax.n, domain:ax.d, vm:vmId,
        pass:false, confidence:0, finding:`Error: ${e.message}`, evidence:"", patricia:false, error:true};
      results.push(r);
      onBit(r);
    }
  }
  return results;
}

function checkFaults(reg) {
  const idx = Object.fromEntries(AXIOMS.map(a=>[a.t,a.b]));
  const active = {};
  for (const [key,fc] of Object.entries(FAULT_CHAINS)) {
    const triggered = fc.nodes.filter(t => reg[idx[t]] === false);
    if (triggered.length > 0) active[key] = {...fc, triggered};
  }
  return active;
}

export default function TophKernel() {
  const [phase, setPhase]     = useState("INIT");
  const [target, setTarget]   = useState({name:"",url:"",desc:"",ctx:""});
  const [reg, setReg]         = useState(new Array(128).fill(null));
  const [vmState, setVmState] = useState({1:"IDLE",2:"IDLE",3:"IDLE",4:"IDLE"});
  const [vmProgress, setVmProgress] = useState({1:0,2:0,3:0,4:0});
  const [findings, setFindings] = useState([]);
  const [faults, setFaults]   = useState({});
  const [logs, setLogs]       = useState({1:[],2:[],3:[],4:[]});
  const [report, setReport]   = useState(null);
  const [activeVM, setActiveVM] = useState(1);
  const logRefs = useRef({1:null,2:null,3:null,4:null});

  const addLog = useCallback((vm, type, msg) => {
    setLogs(prev => ({...prev, [vm]: [...(prev[vm]||[]).slice(-60), {type,msg,ts:Date.now()}]}));
  }, []);

  useEffect(() => {
    const el = logRefs.current[activeVM];
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs, activeVM]);

  const onBit = useCallback((r) => {
    setReg(prev => {
      const next = [...prev];
      next[r.bit] = r.pass;
      setFaults(checkFaults(next));
      return next;
    });
    setVmProgress(prev => ({...prev, [r.vm]: (prev[r.vm]||0)+1}));
    if (!r.pass && !r.error) {
      setFindings(prev => [...prev, r]);
    }
    const icon = r.pass ? "✓" : "✗";
    const tag  = r.px ? "PX" : r.br ? "BR" : "  ";
    addLog(r.vm, r.pass?"pass":"fail", `${icon}${tag} ${r.t}:${r.name} (${r.confidence}%)`);
  }, [addLog]);

  const run = useCallback(async () => {
    if (!target.name || !target.desc) return;
    setPhase("RUNNING");
    setReg(new Array(128).fill(null));
    setFindings([]);
    setFaults({});
    setLogs({1:[],2:[],3:[],4:[]});
    setVmProgress({1:0,2:0,3:0,4:0});
    setVmState({1:"RUNNING",2:"RUNNING",3:"RUNNING",4:"RUNNING"});
    setReport(null);

    addLog(1,"sys","BOOT"); addLog(2,"sys","BOOT");
    addLog(3,"sys","BOOT"); addLog(4,"sys","BOOT");

    // ALL 4 VMs FIRE SIMULTANEOUSLY
    const [r1,r2,r3,r4] = await Promise.all([
      runVM(1,target,onBit).then(r=>{setVmState(p=>({...p,1:"DONE"}));addLog(1,"sys","COMPLETE");return r;}),
      runVM(2,target,onBit).then(r=>{setVmState(p=>({...p,2:"DONE"}));addLog(2,"sys","COMPLETE");return r;}),
      runVM(3,target,onBit).then(r=>{setVmState(p=>({...p,3:"DONE"}));addLog(3,"sys","COMPLETE");return r;}),
      runVM(4,target,onBit).then(r=>{setVmState(p=>({...p,4:"DONE"}));addLog(4,"sys","COMPLETE");return r;}),
    ]);

    const allResults = [...r1,...r2,...r3,...r4];
    const pass = allResults.filter(r=>r.pass).length;
    const fail = allResults.filter(r=>!r.pass&&!r.error).length;
    const allFindings = allResults.filter(r=>!r.pass&&!r.error);
    const finalFaults = checkFaults(Object.fromEntries(allResults.map(r=>[r.bit,r.pass])));

    setReport({
      target:target.name, date:new Date().toISOString().split("T")[0],
      score:Math.round(pass/(pass+fail)*100), pass, fail, total:pass+fail,
      findings:allFindings, faults:finalFaults,
      burdenShifted: allResults.find(r=>r.t==="T064")?.pass===false,
      rootPresent:   allResults.find(r=>r.t==="T128")?.pass===true,
      patricia:      allFindings.filter(r=>r.patricia).length,
      d7fails:       allFindings.filter(r=>r.domain==="D7").length,
    });
    setPhase("DONE");
  }, [target, onBit, addLog]);

  const passCount = reg.filter(b=>b===true).length;
  const failCount = reg.filter(b=>b===false).length;
  const score = passCount+failCount > 0 ? Math.round(passCount/(passCount+failCount)*100) : 0;
  const dc = {D0:"#3b82f6",D1:"#8b5cf6",D2:"#ec4899",D3:"#f59e0b",D4:"#10b981",D5:"#06b6d4",D6:"#f97316",D7:"#ef4444"};

  return (
    <div style={{fontFamily:"'Courier New',monospace",background:"#06090f",color:"#8090a8",minHeight:"100vh",display:"flex",flexDirection:"column",fontSize:12,userSelect:"none"}}>

      {/* TOP BAR */}
      <div style={{background:"#080c14",borderBottom:"2px solid #0e1a2e",padding:"7px 14px",display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
        <span style={{color:"#3b82f6",fontSize:20,lineHeight:1}}>◬</span>
        <span style={{color:"#c0d0e8",fontSize:13,fontWeight:900,letterSpacing:4}}>TOPH KERNEL</span>
        <span style={{background:"#0e1a2e",color:"#3b82f6",padding:"1px 8px",fontSize:10,letterSpacing:3,border:"1px solid #1a3050"}}>v1.0</span>
        <span style={{color:"#1a3050",fontSize:10,letterSpacing:2}}>4 PARALLEL VMs · 128-BIT · Promise.all</span>
        {phase!=="INIT" && (
          <div style={{marginLeft:"auto",display:"flex",gap:10,alignItems:"center"}}>
            <span style={{color:score>=80?"#10b981":score>=50?"#f59e0b":"#ef4444",fontSize:16,fontWeight:900}}>{score}%</span>
            <span style={{color:"#1a3050",fontSize:10}}>{passCount}P / {failCount}F</span>
          </div>
        )}
        <div style={{marginLeft:phase==="INIT"?"auto":"0",display:"flex",gap:4}}>
          {[1,2,3,4].map(v=>(
            <div key={v} style={{width:8,height:8,borderRadius:"50%",
              background:vmState[v]==="RUNNING"?VM_CONFIG[v].color:vmState[v]==="DONE"?VM_CONFIG[v].color+"66":"#1a2a3a",
              boxShadow:vmState[v]==="RUNNING"?`0 0 6px ${VM_CONFIG[v].color}`:""}}/>
          ))}
          <span style={{color:"#1a3050",fontSize:10,letterSpacing:2,marginLeft:4}}>{phase}</span>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minHeight:0}}>

        {/* TARGET INPUT */}
        {phase==="INIT" && (
          <div style={{padding:16,borderBottom:"1px solid #0e1a2e",background:"#080c14"}}>
            <div style={{color:"#3b82f6",fontSize:10,letterSpacing:4,marginBottom:10}}>TARGET ACQUISITION</div>
            <div style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}>
              {Object.entries(EXAMPLES).map(([k,ex])=>(
                <button key={k} onClick={()=>setTarget(ex)}
                  style={{background:"#0a0f1c",border:"1px solid #1a3050",color:"#4a7090",
                    padding:"3px 10px",fontSize:10,fontFamily:"inherit",cursor:"pointer",letterSpacing:1}}>
                  {ex.name}
                </button>
              ))}
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:6}}>
              {[["TARGET NAME","name"],["URL","url"]].map(([lbl,key])=>(
                <div key={key}>
                  <div style={{color:"#1a3050",fontSize:9,letterSpacing:3,marginBottom:2}}>{lbl}</div>
                  <input value={target[key]} onChange={e=>setTarget(p=>({...p,[key]:e.target.value}))}
                    style={{width:"100%",background:"#06090f",border:"1px solid #0e1a2e",color:"#c0d0e8",
                      padding:"5px 8px",fontSize:12,fontFamily:"inherit",outline:"none",boxSizing:"border-box"}}/>
                </div>
              ))}
            </div>
            {[["DESCRIPTION","desc"],["CONTEXT","ctx"]].map(([lbl,key])=>(
              <div key={key} style={{marginBottom:6}}>
                <div style={{color:"#1a3050",fontSize:9,letterSpacing:3,marginBottom:2}}>{lbl}</div>
                <textarea value={target[key]} onChange={e=>setTarget(p=>({...p,[key]:e.target.value}))}
                  rows={key==="desc"?3:2}
                  style={{width:"100%",background:"#06090f",border:"1px solid #0e1a2e",color:"#c0d0e8",
                    padding:"5px 8px",fontSize:12,fontFamily:"inherit",outline:"none",resize:"vertical",boxSizing:"border-box"}}/>
              </div>
            ))}
            <div style={{display:"flex",gap:8,alignItems:"center",marginTop:8}}>
              <button onClick={run} disabled={!target.name||!target.desc}
                style={{background:target.name&&target.desc?"#0e1a2e":"transparent",
                  border:`2px solid ${target.name&&target.desc?"#3b82f6":"#1a2a3a"}`,
                  color:target.name&&target.desc?"#3b82f6":"#1a2a3a",
                  padding:"6px 24px",fontSize:13,fontFamily:"inherit",
                  cursor:target.name&&target.desc?"pointer":"default",letterSpacing:3,fontWeight:900}}>
                ◬ EXECUTE KERNEL
              </button>
              <span style={{color:"#1a2a3a",fontSize:10}}>4 VMs · parallel · ~2-3 min</span>
            </div>
          </div>
        )}

        {/* 128-BIT REGISTER */}
        {phase!=="INIT" && (
          <div style={{padding:"8px 12px",borderBottom:"1px solid #0e1a2e",background:"#080c14"}}>
            <div style={{display:"flex",gap:1,flexWrap:"wrap",marginBottom:4}}>
              {reg.map((b,i)=>{
                const ax = AXIOMS[i];
                const c = dc[ax.d];
                return (
                  <div key={i} title={`${ax.t}:${ax.n}`} style={{
                    width:11,height:11,borderRadius:1,
                    background:b===null?"#0a1020":b?c+"44":"#ef444430",
                    border:b===null?"1px solid #0e1824":b?`1px solid ${c}55`:"1px solid #ef444455",
                    boxShadow:b===true?`0 0 3px ${c}44`:"",transition:"all .15s"}}/>
                );
              })}
            </div>
            {/* Shadow (Patricia) register */}
            <div style={{display:"flex",gap:1,flexWrap:"wrap"}}>
              {reg.map((b,i)=>(
                <div key={i} style={{
                  width:11,height:11,borderRadius:1,
                  background:b===null?"transparent":b?"#06090f":"#a855f722",
                  border:b===null?"1px solid transparent":b?"1px solid #0a1020":"1px solid #a855f733"}}/>
              ))}
            </div>
            <div style={{display:"flex",gap:2,marginTop:3,fontSize:9,color:"#1a3050"}}>
              <span>TOPH</span>
              <span style={{marginLeft:8,color:"#a855f744"}}>SHADOW (Patricia)</span>
              <span style={{marginLeft:"auto"}}>{passCount}P / {failCount}F / {128-passCount-failCount} pending</span>
            </div>
          </div>
        )}

        {/* 4 VM PANELS */}
        {phase!=="INIT" && (
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",flex:1,overflow:"hidden",minHeight:0,borderBottom:"1px solid #0e1a2e"}}>
            {[1,2,3,4].map(v=>{
              const cfg = VM_CONFIG[v];
              const myAxioms = AXIOMS.filter(a=>a.vm===v);
              const myBits = myAxioms.map(a=>reg[a.b]);
              const myPass = myBits.filter(b=>b===true).length;
              const myFail = myBits.filter(b=>b===false).length;
              const myDone = myPass+myFail;
              const isActive = activeVM===v;

              return (
                <div key={v} onClick={()=>setActiveVM(v)}
                  style={{display:"flex",flexDirection:"column",overflow:"hidden",
                    borderRight:v<4?"1px solid #0e1a2e":"none",
                    background:isActive?"#080c14":"#070a10",
                    cursor:"pointer",transition:"background .1s"}}>

                  {/* VM header */}
                  <div style={{padding:"5px 8px",borderBottom:`1px solid ${cfg.color}33`,
                    background:isActive?cfg.color+"18":"transparent"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{display:"flex",gap:5,alignItems:"center"}}>
                        <div style={{width:7,height:7,borderRadius:"50%",
                          background:vmState[v]==="RUNNING"?cfg.color:vmState[v]==="DONE"?cfg.color+"88":"#1a2a3a",
                          boxShadow:vmState[v]==="RUNNING"?`0 0 5px ${cfg.color}`:""}}/>
                        <span style={{color:cfg.color,fontSize:11,fontWeight:900,letterSpacing:2}}>VM{v}</span>
                        <span style={{color:cfg.color,fontSize:10}}>{cfg.arm}</span>
                      </div>
                      <span style={{color:vmState[v]==="DONE"?(myFail===0?"#10b981":"#ef4444"):cfg.color+"66",
                        fontSize:10,fontWeight:900}}>{vmState[v]}</span>
                    </div>
                    <div style={{color:"#2a4060",fontSize:9,letterSpacing:1,marginTop:1}}>{cfg.label}</div>
                    {/* Progress bar */}
                    <div style={{height:2,background:"#0a1020",marginTop:4,borderRadius:1,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${(myDone/32)*100}%`,
                        background:cfg.color,transition:"width .2s",borderRadius:1,
                        boxShadow:`0 0 4px ${cfg.color}`}}/>
                    </div>
                    <div style={{display:"flex",justifyContent:"space-between",marginTop:2,fontSize:9,color:"#1a3050"}}>
                      <span style={{color:"#10b981"}}>{myPass}P</span>
                      <span>{myDone}/32</span>
                      <span style={{color:myFail>0?"#ef4444":"#1a3050"}}>{myFail}F</span>
                    </div>
                  </div>

                  {/* Mini register for this VM */}
                  <div style={{padding:"4px 8px",borderBottom:"1px solid #0e1824",display:"flex",gap:1,flexWrap:"wrap"}}>
                    {myAxioms.map(ax=>(
                      <div key={ax.b} title={`${ax.t}:${ax.n}`} style={{
                        width:8,height:8,borderRadius:1,
                        background:reg[ax.b]===null?"#0a1020":reg[ax.b]?cfg.color+"55":"#ef444440",
                        border:reg[ax.b]===null?"1px solid #0e1824":reg[ax.b]?`1px solid ${cfg.color}44`:"1px solid #ef444455"}}/>
                    ))}
                  </div>

                  {/* Log */}
                  <div ref={el=>logRefs.current[v]=el}
                    style={{flex:1,overflowY:"auto",padding:"4px 8px",fontSize:10,lineHeight:1.5}}>
                    {(logs[v]||[]).map((entry,i)=>(
                      <div key={i} style={{color:
                        entry.type==="pass"?cfg.color+"cc":
                        entry.type==="fail"?"#ef4444aa":
                        entry.type==="sys"?cfg.color:
                        "#2a4060", whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                        {entry.msg}
                      </div>
                    ))}
                    {vmState[v]==="RUNNING" && (
                      <div style={{color:cfg.color,opacity:0.6}}>▌</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* FAULT CHAINS */}
        {Object.keys(faults).length > 0 && (
          <div style={{padding:"5px 12px",borderBottom:"1px solid #0e1a2e",
            background:"#08060f",display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
            <span style={{color:"#2a1a3a",fontSize:9,letterSpacing:2}}>ACTIVE FAULTS:</span>
            {Object.entries(faults).map(([k,fc])=>(
              <div key={k} style={{background:fc.color+"18",border:`1px solid ${fc.color}55`,
                padding:"1px 8px",fontSize:10,color:fc.color,letterSpacing:1}}>
                ⚡ {fc.name}
              </div>
            ))}
          </div>
        )}

        {/* REPORT */}
        {report && (
          <div style={{padding:12,background:"#080c14",borderTop:"2px solid #0e1a2e",overflowY:"auto",maxHeight:280}}>
            <div style={{display:"flex",gap:8,alignItems:"baseline",marginBottom:10}}>
              <span style={{color:"#3b82f6",fontSize:11,letterSpacing:3}}>◬ REPORT</span>
              <span style={{color:report.score>=80?"#10b981":report.score>=50?"#f59e0b":"#ef4444",
                fontSize:20,fontWeight:900}}>{report.score}%</span>
              <span style={{color:"#1a3050",fontSize:10}}>{report.target} · {report.date}</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:5,marginBottom:10}}>
              {[
                {l:"PASS",v:report.pass,c:"#10b981"},
                {l:"FAIL",v:report.fail,c:"#ef4444"},
                {l:"PATRICIA",v:report.patricia,c:"#a855f7"},
                {l:"FAULTS",v:Object.keys(report.faults).length,c:"#f59e0b"},
                {l:"D7 VIOLATIONS",v:report.d7fails,c:"#ef4444"},
                {l:"BURDEN SHIFTED",v:report.burdenShifted?"YES":"NO",c:report.burdenShifted?"#ef4444":"#10b981"},
              ].map(item=>(
                <div key={item.l} style={{background:"#06090f",border:"1px solid #0e1a2e",padding:"5px 7px",textAlign:"center"}}>
                  <div style={{color:"#1a3050",fontSize:8,letterSpacing:1}}>{item.l}</div>
                  <div style={{color:item.c,fontSize:16,fontWeight:900}}>{item.v}</div>
                </div>
              ))}
            </div>
            {Object.keys(report.faults).length > 0 && (
              <div style={{marginBottom:8}}>
                {Object.entries(report.faults).map(([k,fc])=>(
                  <div key={k} style={{marginBottom:3,padding:"3px 8px",
                    borderLeft:`2px solid ${fc.color}`,background:"#06090f",fontSize:10}}>
                    <span style={{color:fc.color}}>⚡ {fc.name}</span>
                    <span style={{color:"#2a4060",marginLeft:6}}>{fc.nodes.join(" → ")}</span>
                    <span style={{color:"#ef4444",marginLeft:6,fontSize:9}}>triggered: {fc.triggered.join(", ")}</span>
                  </div>
                ))}
              </div>
            )}
            <div style={{color:"#2a3a50",fontSize:10,marginBottom:6}}>TOP FINDINGS ({report.findings.length})</div>
            {report.findings.slice(0,8).map((f,i)=>(
              <div key={i} style={{marginBottom:4,padding:"3px 8px",
                borderLeft:`2px solid ${f.patricia?"#a855f7":dc[f.domain]||"#3b82f6"}`,
                background:"#06090f",fontSize:10}}>
                <span style={{color:dc[f.domain]||"#3b82f6"}}>{f.t}:{f.name}</span>
                {f.patricia&&<span style={{color:"#a855f7",fontSize:9,marginLeft:6}}>PATRICIA</span>}
                <span style={{color:"#1a3050",float:"right",fontSize:9}}>{f.confidence}%</span>
                <div style={{color:"#4a6080",marginTop:1}}>{f.finding}</div>
              </div>
            ))}
            <div style={{marginTop:8,color:"#0e1824",fontSize:9}}>
              SHA256:02880745...fcab763 · TRIPOD-IP-v1.1 · DLW · TriPod LLC · 3/4/26
            </div>
          </div>
        )}
      </div>

      <div style={{background:"#080c14",borderTop:"1px solid #0e1a2e",padding:"3px 14px",
        display:"flex",gap:12,color:"#0e1824",fontSize:9,letterSpacing:2}}>
        <span>KERNEL v1.0</span>
        <span>4 VMs · Promise.all · parallel execution</span>
        <span>VM1(+i)D6+D7 · VM2(-i)D0+D1 · VM3(+1)D4+D5 · VM4(-1)D2+D3</span>
        <span style={{marginLeft:"auto"}}>TRIPOD-IP-v1.1 · DLW · TriPod LLC</span>
      </div>
    </div>
  );
}
