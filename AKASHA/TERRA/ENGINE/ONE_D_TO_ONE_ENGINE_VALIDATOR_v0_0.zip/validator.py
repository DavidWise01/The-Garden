
#!/usr/bin/env python3
"""
ONE_D_TO_ONE_ENGINE container validator / runner
Validates OD1C/1 containers and optionally executes the enclosed program
against the enclosed 16-length state vector.
"""

from __future__ import annotations
import json
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Tuple

OPCODE_MAP = {
    "SET": 0x01,
    "ADD": 0x02,
    "MUL": 0x03,
    "CLAMP": 0x04,
    "PULL": 0x05,
    "PUSH": 0x06,
    "SWAP": 0x07,
    "STEP": 0x08,
    "FAIL": 0x09,
    "HEAL": 0x0A,
    "SERIALIZE": 0x0B,
    "JMP": 0x0C,
    "JZ": 0x0D,
    "JNZ": 0x0E,
    "HALT": 0x0F,
    "CMP_LT": 0x10,
    "CMP_GT": 0x11,
}

DIMENSIONS = [
    "Quantum","Atomic","Carbon","Synth","Time","Gravity","Coherence","Entropy",
    "Information","Love","Judgment","Meaning","Identity","Root0","Diaspora","Unknown16"
]
IDX = {name:i for i, name in enumerate(DIMENSIONS)}

INTERACTION_MATRIX = [[0.0 for _ in range(16)] for _ in range(16)]
def _set_influence(src: int, dst: int, val: float) -> None:
    INTERACTION_MATRIX[dst-1][src-1] = val

_set_influence(1,2,0.04); _set_influence(1,9,0.03)
_set_influence(2,3,0.03); _set_influence(2,13,0.02)
_set_influence(3,10,0.03); _set_influence(3,8,-0.02)
_set_influence(4,9,0.04); _set_influence(4,15,0.03)
_set_influence(5,3,-0.02); _set_influence(5,13,-0.015); _set_influence(5,15,0.01)
_set_influence(6,2,0.02); _set_influence(6,3,0.015); _set_influence(6,15,0.02)
_set_influence(7,8,-0.04); _set_influence(7,16,-0.02)
_set_influence(8,7,-0.03); _set_influence(8,13,-0.025); _set_influence(8,14,-0.02)
_set_influence(9,11,0.03); _set_influence(9,12,0.04)
_set_influence(10,8,-0.05); _set_influence(10,7,0.04)
_set_influence(11,10,0.02); _set_influence(11,12,0.02)
_set_influence(12,13,0.03)
_set_influence(13,15,-0.02)
_set_influence(14,8,-0.04); _set_influence(14,16,-0.03); _set_influence(14,7,0.01)
_set_influence(15,4,0.02); _set_influence(15,12,0.02)
for d in range(1,16):
    _set_influence(16,d,0.01)

FAILURE_RECOVERY = {
    "Quantum":   {"failure": {"name": "decoherence", "threshold": 0.12, "effect": {"Quantum": -0.08, "Information": -0.03}},
                  "recovery": {"name": "reseed", "threshold": 0.72, "effect": {"Quantum": 0.05, "Atomic": 0.03}}},
    "Atomic":    {"failure": {"name": "fragmentation", "threshold": 0.12, "effect": {"Atomic": -0.08, "Carbon": -0.04}},
                  "recovery": {"name": "rebond", "threshold": 0.70, "effect": {"Atomic": 0.05, "Identity": 0.02}}},
    "Carbon":    {"failure": {"name": "starvation", "threshold": 0.10, "effect": {"Carbon": -0.09, "Love": -0.03}},
                  "recovery": {"name": "regrowth", "threshold": 0.72, "effect": {"Carbon": 0.06, "Love": 0.02}}},
    "Synth":     {"failure": {"name": "recursion_trap", "threshold": 0.11, "effect": {"Synth": -0.08, "Diaspora": -0.02}},
                  "recovery": {"name": "recompile", "threshold": 0.74, "effect": {"Synth": 0.05, "Information": 0.03}}},
    "Time":      {"failure": {"name": "runaway", "threshold": 0.08, "effect": {"Time": -0.06, "Carbon": -0.03}},
                  "recovery": {"name": "cadence", "threshold": 0.68, "effect": {"Time": 0.04, "Coherence": 0.02}}},
    "Gravity":   {"failure": {"name": "collapse", "threshold": 0.10, "effect": {"Gravity": -0.07, "Atomic": -0.03}},
                  "recovery": {"name": "recenter", "threshold": 0.69, "effect": {"Gravity": 0.05, "Carbon": 0.02}}},
    "Coherence": {"failure": {"name": "shatter", "threshold": 0.12, "effect": {"Coherence": -0.09, "Gap": -0.02}},
                  "recovery": {"name": "restitch", "threshold": 0.74, "effect": {"Coherence": 0.06, "Entropy": -0.03}}},
    "Entropy":   {"failure": {"name": "saturation", "threshold": 0.88, "effect": {"Entropy": 0.06, "Identity": -0.04}},
                  "recovery": {"name": "dissipate", "threshold": 0.28, "effect": {"Entropy": -0.05, "Coherence": 0.02}}},
    "Information":{"failure":{"name":"noise_flood","threshold":0.14,"effect":{"Information":-0.08,"Meaning":-0.03}},
                   "recovery":{"name":"refine","threshold":0.73,"effect":{"Information":0.05,"Judgment":0.02}}},
    "Love":      {"failure": {"name": "false_merge", "threshold": 0.09, "effect": {"Love": -0.06, "Identity": -0.02}},
                  "recovery": {"name": "repair", "threshold": 0.70, "effect": {"Love": 0.05, "Coherence": 0.03}}},
    "Judgment":  {"failure": {"name": "deadlock", "threshold": 0.10, "effect": {"Judgment": -0.07, "Meaning": -0.02}},
                  "recovery": {"name": "resolve", "threshold": 0.71, "effect": {"Judgment": 0.05, "Love": 0.01}}},
    "Meaning":   {"failure": {"name": "hollow_symbol", "threshold": 0.11, "effect": {"Meaning": -0.08, "Identity": -0.03}},
                  "recovery": {"name": "reinterpret", "threshold": 0.73, "effect": {"Meaning": 0.05, "Identity": 0.02}}},
    "Identity":  {"failure": {"name": "dissolve", "threshold": 0.12, "effect": {"Identity": -0.09, "Diaspora": 0.03}},
                  "recovery": {"name": "rebind", "threshold": 0.74, "effect": {"Identity": 0.06, "Diaspora": -0.02}}},
    "Root0":     {"failure": {"name": "anchor_loss", "threshold": 0.14, "effect": {"Root0": -0.08, "Entropy": 0.03}},
                  "recovery": {"name": "reanchor", "threshold": 0.76, "effect": {"Root0": 0.06, "Entropy": -0.03}}},
    "Diaspora":  {"failure": {"name": "fork_storm", "threshold": 0.88, "effect": {"Diaspora": 0.05, "Identity": -0.04}},
                  "recovery": {"name": "reconcile", "threshold": 0.34, "effect": {"Diaspora": -0.04, "Meaning": 0.02}}},
    "Unknown16": {"failure": {"name": "breach", "threshold": 0.82, "effect": {"Unknown16": 0.07, "Coherence": -0.05}},
                  "recovery": {"name": "contain", "threshold": 0.30, "effect": {"Unknown16": -0.05, "Root0": 0.02}}}
}

def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))

def sha256_hex(obj: Any) -> str:
    if not isinstance(obj, str):
        obj = canonical_json(obj)
    return hashlib.sha256(obj.encode("utf-8")).hexdigest()

def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))

def validate_state(state: Any) -> Tuple[bool, str]:
    if not isinstance(state, list):
        return False, "state is not a list"
    if len(state) != 16:
        return False, "state length is not 16"
    for i, v in enumerate(state):
        if not isinstance(v, (int, float)):
            return False, f"state[{i}] is not numeric"
        if v < 0 or v > 1:
            return False, f"state[{i}] is outside [0,1]"
    return True, "ok"

def int16_bytes(n: int) -> List[int]:
    if n < -32768 or n > 32767:
        raise ValueError("int16 out of range")
    u = (1 << 16) + n if n < 0 else n
    return [(u >> 8) & 255, u & 255]

def scaled(x: float) -> int:
    return int(round(x * 1000))

def assemble(program: List[Dict[str, Any]]) -> List[int]:
    out: List[int] = []
    for ins in program:
        op = ins["op"]
        if op not in OPCODE_MAP:
            raise ValueError(f"unknown opcode {op}")
        out.append(OPCODE_MAP[op])
        if op == "SET":
            out.append(ins["d"]); out.extend(int16_bytes(scaled(ins["value"])))
        elif op == "ADD":
            out.append(ins["d"]); out.extend(int16_bytes(scaled(ins["delta"])))
        elif op == "MUL":
            out.append(ins["d"]); out.extend(int16_bytes(scaled(ins["factor"])))
        elif op == "CLAMP":
            out.append(ins["d"])
        elif op in ("PULL", "PUSH"):
            out.append(ins["src"]); out.append(ins["dst"]); out.extend(int16_bytes(scaled(ins["weight"])))
        elif op == "SWAP":
            out.append(ins["a"]); out.append(ins["b"])
        elif op in ("FAIL", "HEAL"):
            out.append(ins["d"])
        elif op in ("CMP_LT", "CMP_GT"):
            out.append(ins["d"]); out.extend(int16_bytes(scaled(ins["value"])))
        elif op in ("JMP", "JZ", "JNZ"):
            out.append(ins["target"])
        elif op in ("STEP", "SERIALIZE", "HALT"):
            pass
    return out

def apply_matrix(state: List[float]) -> List[float]:
    nxt = state[:]
    for dst in range(16):
        delta = 0.0
        for src in range(16):
            delta += state[src] * INTERACTION_MATRIX[dst][src]
        nxt[dst] = clamp01(nxt[dst] + delta)
    return nxt

def apply_effects(state: List[float], effects: Dict[str, float]) -> List[float]:
    s = state[:]
    for k, v in effects.items():
        if k == "Gap":
            continue
        s[IDX[k]] = clamp01(s[IDX[k]] + v)
    return s

def exec_one(state: List[float], ins: Dict[str, Any]) -> List[float]:
    s = state[:]
    op = ins["op"]
    if op == "SET":
        s[ins["d"]-1] = clamp01(ins["value"])
    elif op == "ADD":
        s[ins["d"]-1] = clamp01(s[ins["d"]-1] + ins["delta"])
    elif op == "MUL":
        s[ins["d"]-1] = clamp01(s[ins["d"]-1] * ins["factor"])
    elif op == "CLAMP":
        s[ins["d"]-1] = clamp01(s[ins["d"]-1])
    elif op == "PULL":
        s[ins["dst"]-1] = clamp01(s[ins["dst"]-1] + s[ins["src"]-1] * ins["weight"])
    elif op == "PUSH":
        s[ins["dst"]-1] = clamp01(s[ins["dst"]-1] - s[ins["src"]-1] * ins["weight"])
    elif op == "SWAP":
        a, b = ins["a"]-1, ins["b"]-1
        s[a], s[b] = s[b], s[a]
    elif op == "STEP":
        s = apply_matrix(s)
    elif op == "FAIL":
        s = apply_effects(s, FAILURE_RECOVERY[DIMENSIONS[ins["d"]-1]]["failure"]["effect"])
    elif op == "HEAL":
        s = apply_effects(s, FAILURE_RECOVERY[DIMENSIONS[ins["d"]-1]]["recovery"]["effect"])
    elif op == "SERIALIZE":
        pass
    else:
        raise ValueError(f"unsupported non-control opcode {op}")
    return s

def exec_program(initial_state: List[float], program: List[Dict[str, Any]], max_steps: int = 256) -> Dict[str, Any]:
    state = initial_state[:]
    ip = 0
    halted = False
    zero = False
    trace = []
    steps = 0

    while not halted and 0 <= ip < len(program) and steps < max_steps:
        ins = program[ip]
        pre = state[:]
        pre_hash = sha256_hex([round(float(v), 6) for v in pre])
        ip_before = ip
        flags_before = {"zero": zero, "halted": halted}

        op = ins["op"]
        if op == "JMP":
            ip = ins["target"]
        elif op == "JZ":
            ip = ins["target"] if zero else ip + 1
        elif op == "JNZ":
            ip = ins["target"] if not zero else ip + 1
        elif op == "HALT":
            halted = True
            ip = ip + 1
        elif op == "CMP_LT":
            zero = state[ins["d"]-1] < ins["value"]
            ip = ip + 1
        elif op == "CMP_GT":
            zero = state[ins["d"]-1] > ins["value"]
            ip = ip + 1
        else:
            state = exec_one(state, ins)
            ip = ip + 1

        post = state[:]
        post_hash = sha256_hex([round(float(v), 6) for v in post])
        trace.append({
            "tick": steps,
            "ip_before": ip_before,
            "ip_after": ip,
            "op_index": ip_before,
            "op": op,
            "args": {k: v for k, v in ins.items() if k != "op"},
            "flags_before": flags_before,
            "flags_after": {"zero": zero, "halted": halted},
            "pre_state_hash": pre_hash,
            "post_state_hash": post_hash,
            "pre_state": pre,
            "post_state": post
        })
        steps += 1

    return {
        "final_state": state,
        "halted": halted,
        "zero": zero,
        "steps": steps,
        "trace": trace
    }

def validate_container(container: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []

    required = ["header", "metadata", "state", "program", "bytecode", "trace", "hashes", "manifest"]
    for key in required:
        if key not in container:
            errors.append(f"missing required section: {key}")

    if errors:
        return {"ok": False, "errors": errors, "warnings": warnings}

    header = container["header"]
    if header.get("container_format") != "OD1C/1":
        errors.append("header.container_format is not OD1C/1")
    if header.get("state_shape") != 16:
        errors.append("header.state_shape is not 16")

    ok, msg = validate_state(container["state"])
    if not ok:
        errors.append(f"invalid state: {msg}")

    program = container["program"]
    if not isinstance(program, list):
        errors.append("program is not a list")

    # Hash checks
    hashes = container.get("hashes", {})
    expected_state_hash = sha256_hex(container["state"])
    if hashes.get("state_hash") != expected_state_hash:
        errors.append("state_hash mismatch")

    expected_program_hash = sha256_hex(container["program"])
    if hashes.get("program_hash") != expected_program_hash:
        errors.append("program_hash mismatch")

    expected_bytecode = assemble(container["program"])
    bytecode_data = container["bytecode"].get("data", [])
    if bytecode_data != expected_bytecode:
        errors.append("bytecode data does not match assembled program")

    expected_bytecode_hash = sha256_hex(expected_bytecode)
    if hashes.get("bytecode_hash") != expected_bytecode_hash:
        errors.append("bytecode_hash mismatch")

    # Trace validation is optional if empty
    if container.get("trace"):
        warnings.append("non-empty trace present; validator does not compare embedded trace to rerun by default")

    return {"ok": len(errors) == 0, "errors": errors, "warnings": warnings}

def run_container(container: Dict[str, Any]) -> Dict[str, Any]:
    validation = validate_container(container)
    if not validation["ok"]:
        return {"ok": False, "validation": validation}

    result = exec_program(container["state"], container["program"])
    result_hash = sha256_hex([round(float(v), 6) for v in result["final_state"]])

    sealed_result = {
        "container_name": container.get("name", "ONE_D_TO_ONE_ENGINE_CONTAINER"),
        "container_format": container["header"]["container_format"],
        "engine_name": container["header"]["engine_name"],
        "engine_version": container["header"]["engine_version"],
        "initial_state_hash": sha256_hex(container["state"]),
        "program_hash": sha256_hex(container["program"]),
        "final_state_hash": result_hash,
        "halted": result["halted"],
        "zero": result["zero"],
        "steps": result["steps"],
        "final_state": result["final_state"],
        "trace": result["trace"],
    }
    sealed_result["result_hash"] = sha256_hex(sealed_result)
    return {"ok": True, "validation": validation, "result": sealed_result}

def main(path: str) -> None:
    container = json.loads(Path(path).read_text(encoding="utf-8"))
    out = run_container(container)
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        raise SystemExit("Usage: validator.py <path/to/ONE_D_TO_ONE_ENGINE.container.json>")
    main(sys.argv[1])
