The validator is designed to run against the canonical container file:
`ONE_D_TO_ONE_ENGINE.container.json`

It does not require network access and has no hidden state.
