# ONE_D_TO_ONE_ENGINE Validator / Runner

This validator opens an OD1C/1 canonical container and checks:
- required sections
- state shape and value range
- state hash
- program hash
- bytecode consistency against assembled program
- bytecode hash

If validation passes, it executes the enclosed program deterministically and emits:
- final state
- trace
- final state hash
- sealed result hash

Usage:
```bash
python validator.py ONE_D_TO_ONE_ENGINE.container.json
```
