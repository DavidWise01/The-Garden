# ONE_D_TO_ONE_ENGINE v0.0 — Control Flow

This package adds the next best layer:
- deterministic control flow
- flags
- branching
- halting
- sample branching program
- sample branching trace

Artifacts:
- ONE_D_TO_ONE_ENGINE.control_flow.spec.json
- ONE_D_TO_ONE_ENGINE.control_flow.js
- ONE_D_TO_ONE_ENGINE.control_flow.sample_program.json
- ONE_D_TO_ONE_ENGINE.control_flow.sample_trace.json
- CANON.md
- README.md
