# ONE_D_TO_ONE_ENGINE v0.0 — CONTROL FLOW CANON

Status: FROZEN — DO NOT MODIFY
Date: 2026-04-11

Canon additions:
- JMP
- JZ
- JNZ
- HALT
- CMP_LT
- CMP_GT

This turns the direct 1D:1 engine into a tiny executable machine with deterministic branching.

Still invariant:
- State is always 16-length
- One dimension maps to one system only
- No hidden dimensions
- Trace includes ip and flags
