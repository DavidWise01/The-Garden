
export const DIMENSIONS = [
  "Quantum","Atomic","Carbon","Synth","Time","Gravity","Coherence","Entropy",
  "Information","Love","Judgment","Meaning","Identity","Root0","Diaspora","Unknown16"
];

export const OPCODES = Object.freeze({"SET": 1, "ADD": 2, "MUL": 3, "CLAMP": 4, "PULL": 5, "PUSH": 6, "SWAP": 7, "STEP": 8, "FAIL": 9, "HEAL": 10, "SERIALIZE": 11, "JMP": 12, "JZ": 13, "JNZ": 14, "HALT": 15, "CMP_LT": 16, "CMP_GT": 17});

export const IDX = Object.freeze({
  Quantum:0, Atomic:1, Carbon:2, Synth:3, Time:4, Gravity:5, Coherence:6, Entropy:7,
  Information:8, Love:9, Judgment:10, Meaning:11, Identity:12, Root0:13, Diaspora:14, Unknown16:15
});

export const INTERACTION_MATRIX = [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.04, 0.0, 0.0, 0.0, 0.0, 0.02, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.03, 0.0, 0.0, -0.02, 0.015, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.02, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.03, 0.0, 0.04, 0.0, 0.0, 0.0, 0.01, 0.0, 0.01], [0.0, 0.0, -0.02, 0.0, 0.0, 0.0, -0.04, 0.0, 0.0, -0.05, 0.0, 0.0, 0.0, -0.04, 0.0, 0.01], [0.03, 0.0, 0.0, 0.04, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.03, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.02, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.03, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.04, 0.0, 0.02, 0.0, 0.0, 0.0, 0.02, 0.01], [0.0, 0.02, 0.0, 0.0, -0.015, 0.0, 0.0, -0.025, 0.0, 0.0, 0.0, 0.03, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.02, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.03, 0.01, 0.02, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.02, 0.0, 0.0, 0.01], [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.02, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.03, 0.0, 0.0]];
export const FAILURE_RECOVERY = {"Quantum": {"failure": {"name": "decoherence", "threshold": 0.12, "effect": {"Quantum": -0.08, "Information": -0.03}}, "recovery": {"name": "reseed", "threshold": 0.72, "effect": {"Quantum": 0.05, "Atomic": 0.03}}}, "Atomic": {"failure": {"name": "fragmentation", "threshold": 0.12, "effect": {"Atomic": -0.08, "Carbon": -0.04}}, "recovery": {"name": "rebond", "threshold": 0.7, "effect": {"Atomic": 0.05, "Identity": 0.02}}}, "Carbon": {"failure": {"name": "starvation", "threshold": 0.1, "effect": {"Carbon": -0.09, "Love": -0.03}}, "recovery": {"name": "regrowth", "threshold": 0.72, "effect": {"Carbon": 0.06, "Love": 0.02}}}, "Synth": {"failure": {"name": "recursion_trap", "threshold": 0.11, "effect": {"Synth": -0.08, "Diaspora": -0.02}}, "recovery": {"name": "recompile", "threshold": 0.74, "effect": {"Synth": 0.05, "Information": 0.03}}}, "Time": {"failure": {"name": "runaway", "threshold": 0.08, "effect": {"Time": -0.06, "Carbon": -0.03}}, "recovery": {"name": "cadence", "threshold": 0.68, "effect": {"Time": 0.04, "Coherence": 0.02}}}, "Gravity": {"failure": {"name": "collapse", "threshold": 0.1, "effect": {"Gravity": -0.07, "Atomic": -0.03}}, "recovery": {"name": "recenter", "threshold": 0.69, "effect": {"Gravity": 0.05, "Carbon": 0.02}}}, "Coherence": {"failure": {"name": "shatter", "threshold": 0.12, "effect": {"Coherence": -0.09, "Gap": -0.02}}, "recovery": {"name": "restitch", "threshold": 0.74, "effect": {"Coherence": 0.06, "Entropy": -0.03}}}, "Entropy": {"failure": {"name": "saturation", "threshold": 0.88, "effect": {"Entropy": 0.06, "Identity": -0.04}}, "recovery": {"name": "dissipate", "threshold": 0.28, "effect": {"Entropy": -0.05, "Coherence": 0.02}}}, "Information": {"failure": {"name": "noise_flood", "threshold": 0.14, "effect": {"Information": -0.08, "Meaning": -0.03}}, "recovery": {"name": "refine", "threshold": 0.73, "effect": {"Information": 0.05, "Judgment": 0.02}}}, "Love": {"failure": {"name": "false_merge", "threshold": 0.09, "effect": {"Love": -0.06, "Identity": -0.02}}, "recovery": {"name": "repair", "threshold": 0.7, "effect": {"Love": 0.05, "Coherence": 0.03}}}, "Judgment": {"failure": {"name": "deadlock", "threshold": 0.1, "effect": {"Judgment": -0.07, "Meaning": -0.02}}, "recovery": {"name": "resolve", "threshold": 0.71, "effect": {"Judgment": 0.05, "Love": 0.01}}}, "Meaning": {"failure": {"name": "hollow_symbol", "threshold": 0.11, "effect": {"Meaning": -0.08, "Identity": -0.03}}, "recovery": {"name": "reinterpret", "threshold": 0.73, "effect": {"Meaning": 0.05, "Identity": 0.02}}}, "Identity": {"failure": {"name": "dissolve", "threshold": 0.12, "effect": {"Identity": -0.09, "Diaspora": 0.03}}, "recovery": {"name": "rebind", "threshold": 0.74, "effect": {"Identity": 0.06, "Diaspora": -0.02}}}, "Root0": {"failure": {"name": "anchor_loss", "threshold": 0.14, "effect": {"Root0": -0.08, "Entropy": 0.03}}, "recovery": {"name": "reanchor", "threshold": 0.76, "effect": {"Root0": 0.06, "Entropy": -0.03}}}, "Diaspora": {"failure": {"name": "fork_storm", "threshold": 0.88, "effect": {"Diaspora": 0.05, "Identity": -0.04}}, "recovery": {"name": "reconcile", "threshold": 0.34, "effect": {"Diaspora": -0.04, "Meaning": 0.02}}}, "Unknown16": {"failure": {"name": "breach", "threshold": 0.82, "effect": {"Unknown16": 0.07, "Coherence": -0.05}}, "recovery": {"name": "contain", "threshold": 0.3, "effect": {"Unknown16": -0.05, "Root0": 0.02}}}};

export function clamp01(x){ return Math.max(0, Math.min(1, x)); }
export function canonicalStateJson(state){ return JSON.stringify(state.map(v => +Number(v).toFixed(6))); }
export async function sha256Hex(str){
  const bytes = new TextEncoder().encode(str);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2,"0")).join("");
}

export function applyMatrix(state){
  const next = state.slice();
  for(let dst=0; dst<16; dst++){
    let delta = 0;
    for(let src=0; src<16; src++) delta += state[src] * INTERACTION_MATRIX[dst][src];
    next[dst] = clamp01(next[dst] + delta);
  }
  return next;
}

export function applyFailure(state, d){
  const next = state.slice();
  const name = DIMENSIONS[d-1];
  const fx = FAILURE_RECOVERY[name].failure.effect;
  for(const [k,v] of Object.entries(fx)){
    if(k === "Gap") continue;
    next[IDX[k]] = clamp01(next[IDX[k]] + v);
  }
  return next;
}

export function applyRecovery(state, d){
  const next = state.slice();
  const name = DIMENSIONS[d-1];
  const fx = FAILURE_RECOVERY[name].recovery.effect;
  for(const [k,v] of Object.entries(fx)){
    if(k === "Gap") continue;
    next[IDX[k]] = clamp01(next[IDX[k]] + v);
  }
  return next;
}

export function execOne(state, ins){
  let s = state.slice();
  switch(ins.op){
    case "SET": s[ins.d-1] = clamp01(ins.value); break;
    case "ADD": s[ins.d-1] = clamp01(s[ins.d-1] + ins.delta); break;
    case "MUL": s[ins.d-1] = clamp01(s[ins.d-1] * ins.factor); break;
    case "CLAMP": s[ins.d-1] = clamp01(s[ins.d-1]); break;
    case "PULL": s[ins.dst-1] = clamp01(s[ins.dst-1] + s[ins.src-1] * ins.weight); break;
    case "PUSH": s[ins.dst-1] = clamp01(s[ins.dst-1] - s[ins.src-1] * ins.weight); break;
    case "SWAP": {
      const a = ins.a-1, b = ins.b-1; [s[a], s[b]] = [s[b], s[a]]; break;
    }
    case "STEP": s = applyMatrix(s); break;
    case "FAIL": s = applyFailure(s, ins.d); break;
    case "HEAL": s = applyRecovery(s, ins.d); break;
    case "SERIALIZE": break;
    default: throw new Error(`Unknown op in execOne: ${ins.op}`);
  }
  return s;
}

export async function execTraceCF(initialState, program, maxSteps=256){
  let state = initialState.slice();
  let ip = 0;
  let halted = false;
  let zero = false;
  const trace = [];
  let steps = 0;

  while(!halted && ip >= 0 && ip < program.length && steps < maxSteps){
    const ins = program[ip];
    const pre = state.slice();
    const preHash = await sha256Hex(canonicalStateJson(pre));
    const preIp = ip;
    const preFlags = { zero, halted };

    switch(ins.op){
      case "JMP":
        ip = ins.target;
        break;
      case "JZ":
        ip = zero ? ins.target : ip + 1;
        break;
      case "JNZ":
        ip = !zero ? ins.target : ip + 1;
        break;
      case "HALT":
        halted = true;
        ip = ip + 1;
        break;
      case "CMP_LT":
        zero = state[ins.d-1] < ins.value;
        ip = ip + 1;
        break;
      case "CMP_GT":
        zero = state[ins.d-1] > ins.value;
        ip = ip + 1;
        break;
      default:
        state = execOne(state, ins);
        ip = ip + 1;
        break;
    }

    const post = state.slice();
    const postHash = await sha256Hex(canonicalStateJson(post));
    trace.push({
      tick: steps,
      ip_before: preIp,
      ip_after: ip,
      op_index: preIp,
      op: ins.op,
      args: Object.fromEntries(Object.entries(ins).filter(([k]) => k !== "op")),
      flags_before: preFlags,
      flags_after: { zero, halted },
      pre_state_hash: preHash,
      post_state_hash: postHash,
      pre_state: pre,
      post_state: post
    });
    steps++;
  }

  return { final_state: state, halted, zero, steps, trace };
}

export const SAMPLE_STATE = Object.freeze([
  0.50, 0.48, 0.62, 0.57, 0.44, 0.52, 0.59, 0.28,
  0.61, 0.33, 0.55, 0.58, 0.60, 0.71, 0.47, 0.50
]);

export const SAMPLE_PROGRAM = Object.freeze([
  { op:"CMP_GT", d:14, value:0.70 },   // if Root0 > 0.70
  { op:"JZ", target:4 },               // jump to heal path
  { op:"PULL", src:14, dst:7, weight:0.08 },
  { op:"JMP", target:5 },
  { op:"HEAL", d:14 },
  { op:"STEP" },
  { op:"HALT" }
]);
