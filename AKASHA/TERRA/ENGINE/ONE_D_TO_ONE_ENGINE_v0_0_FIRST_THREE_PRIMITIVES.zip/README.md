# ONE_D_TO_ONE_ENGINE v0.0 — First Three Primitives

Included:
- canonical 16x16 interaction matrix
- canonical per-dimension failure/recovery primitives
- canonical small instruction set

This extends the direct 1D:1 engine downward into precision.
No new dimensions were introduced.
