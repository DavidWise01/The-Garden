# ONE_D_TO_ONE_ENGINE — Canonical Container

This package defines and includes the first canonical container format for the 1D:1 engine.

Files:
- ONE_D_TO_ONE_ENGINE.container.spec.json
- ONE_D_TO_ONE_ENGINE.container.json
- CANON.md
- README.md

Format:
OD1C/1
