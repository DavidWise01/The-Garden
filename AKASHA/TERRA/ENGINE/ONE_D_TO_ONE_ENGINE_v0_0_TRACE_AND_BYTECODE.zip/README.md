# ONE_D_TO_ONE_ENGINE v0.0 — Trace + Bytecode

This package adds the strongest next layer:
- deterministic trace format
- exact replay hashes
- fixed opcode map
- assembler/disassembler helpers
- sample program + sample trace + sample bytecode

Artifacts:
- ONE_D_TO_ONE_ENGINE.trace.spec.json
- ONE_D_TO_ONE_ENGINE.trace_bytecode.js
- ONE_D_TO_ONE_ENGINE.sample_program.json
- ONE_D_TO_ONE_ENGINE.sample_trace.json
- ONE_D_TO_ONE_ENGINE.sample_bytecode.json
