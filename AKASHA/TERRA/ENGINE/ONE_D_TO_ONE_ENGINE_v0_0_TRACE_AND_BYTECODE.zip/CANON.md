# ONE_D_TO_ONE_ENGINE v0.0 — TRACE AND BYTECODE CANON

Status: FROZEN — DO NOT MODIFY
Date: 2026-04-11

Canon additions:
1. TRACE FORMAT — deterministic replay record with pre/post state hashes
2. BYTECODE ENCODING — fixed opcode map for canonical instruction serialization

Purpose:
- exact replay
- exact verification
- exact program transport

Still invariant:
- state is always a 16-length vector
- one dimension maps to one system only
- no hidden dimensions
- Root0 = d14
- Unknown16 = d16
