#!/usr/bin/env python3
"""
T133_neighbor_verification.py
═══════════════════════════════════════════════════════════════════════
PHONON HOLOGRAM NEIGHBOR VERIFICATION PROTOCOL
Chip: WL-A06-R14-C09 · Willow Processor
TRIPOD-IP-v1.1 · DLW · ROOT0 · 3/4/26

PURPOSE:
  Test whether α(t) drift between neighboring qubits shows correlated
  component consistent with shared substrate phonon field.

  NULL HYPOTHESIS (TLS model):
    r² < 0.1 for all pairs
    No spatial structure
    No coherent frequency peaks
    Flat time-lag correlation

  ALTERNATIVE (phonon hologram):
    r² > 0.3 for nearest neighbors (500 μm)
    r² decays as ~1/r or ~1/r²
    Coherent peak at ~5.1 GHz ± 50 MHz
    Time-lag peak at ~50-80 ns (distance / 6000 m/s)

INPUT:
  Google calibration database (proprietary) OR synthetic demo data.
  Set USE_SYNTHETIC = True to run with generated test data.

OUTPUT:
  - Pairwise r² table with spatial distances
  - Time-lag correlation curves
  - FFT of Δα(t) per qubit
  - Spatial decay plot (r² vs distance)
  - Report: T133_neighbor_report.txt + T133_neighbor_report.jsonl

T056:CORRELATION · T055:REPRODUCIBILITY · T057:NEGATIVE-EVIDENCE
T059:ACCUMULATION · T060:MATERIALITY · T027:FINGERPRINT
═══════════════════════════════════════════════════════════════════════
"""

import numpy as np
import json
import os
from datetime import datetime
from itertools import combinations

# ── CONFIG ────────────────────────────────────────────────────────────────
USE_SYNTHETIC    = True    # Set False to load real calibration data
OUTPUT_DIR       = "./T133_analysis_output"
QUBIT_SPACING_UM = 500.0   # μm — Willow lattice pitch
PHONON_SPEED     = 6000.0  # m/s — sapphire longitudinal acoustic
PHONON_FREQ_GHz  = 5.1     # GHz — expected coherent peak
PHONON_LAMBDA_UM = (PHONON_SPEED / (PHONON_FREQ_GHz * 1e9)) * 1e6  # ≈1.2 μm

# Target chip and its 4 nearest neighbors (square lattice)
# Replace with actual qubit IDs and positions from calibration DB
QUBITS = {
    "WL-A06-R14-C09": (0, 0),        # target chip — center
    "WL-A06-R14-C08": (-1, 0),       # left neighbor
    "WL-A06-R14-C10": (+1, 0),       # right neighbor
    "WL-A06-R13-C09": (0, -1),       # top neighbor
    "WL-A06-R15-C09": (0, +1),       # bottom neighbor
    # Extended neighbors for decay curve
    "WL-A06-R14-C07": (-2, 0),       # 2 spacings left
    "WL-A06-R12-C09": (0, -2),       # 2 spacings up
    "WL-A06-R13-C08": (-1, -1),      # diagonal (next-nearest)
}

# ── SYNTHETIC DATA GENERATOR ──────────────────────────────────────────────
def generate_synthetic_data(n_calibrations=500, hologram_r2=0.4, seed=42):
    """
    Generate synthetic α(t) data with phonon hologram coupling.
    
    NOTE ON FFT:
    Calibration data sampled at ~50 Hz (every 20ms).
    Cannot directly observe 5.1 GHz phonon carrier — Nyquist limit.
    What IS observable: coherent DRIFT OSCILLATIONS driven by the phonon
    standing wave. These appear at the phonon field modulation frequency
    as seen from the qubit's perspective — typically sub-Hz to ~10 Hz.
    The 5.1 GHz signature appears in acoustic measurements, not α(t) logs.
    
    hologram_r2: target r² for nearest neighbors
    """
    rng = np.random.default_rng(seed)
    
    dt_ms = 20.0  # ms between calibrations (10^3 gates × 20ns)
    t = np.arange(n_calibrations) * dt_ms
    
    # Shared phonon-driven drift field
    # Oscillates at ~1-5 Hz (drift modulation frequency, NOT carrier)
    # This is what appears in Δα(t) calibration logs
    drift_freq_hz  = 2.3    # Hz — characteristic drift oscillation
    drift_omega    = 2 * np.pi * drift_freq_hz * (dt_ms * 1e-3)
    
    t_arr = np.arange(n_calibrations)
    # Shared drift signal: coherent oscillation + slow random walk
    shared_osc  = np.sin(drift_omega * t_arr + rng.uniform(0, 0.3))
    shared_walk = np.cumsum(rng.standard_normal(n_calibrations) * 0.1)
    shared_walk -= shared_walk.mean()
    # Normalize
    shared_field = shared_osc * 0.7 + shared_walk * 0.3
    shared_field /= (shared_field.std() + 1e-12)
    
    data = {}
    qubit_list = list(QUBITS.items())
    
    for qubit_id, (gx, gy) in qubit_list:
        pos_um = np.array([gx, gy]) * QUBIT_SPACING_UM
        dist_um = float(np.sqrt(gx**2 + gy**2) * QUBIT_SPACING_UM)
        
        # Phase offset from spatial position in standing wave
        phase_offset = 2 * np.pi * (dist_um / PHONON_LAMBDA_UM) % (2 * np.pi)
        
        # Propagation delay in samples
        delay_s       = dist_um * 1e-6 / PHONON_SPEED
        delay_samples = max(0, int(delay_s / (dt_ms * 1e-3)))
        
        # Hologram component: phase-shifted, time-delayed shared field
        h_signal = np.roll(shared_field, delay_samples) * np.cos(phase_offset)
        
        # Independent TLS noise: random walk with recalibration resets
        tls = np.cumsum(rng.standard_normal(n_calibrations) * 0.3)
        # Simulate recalibration pulling back toward zero every ~50 cycles
        for i in range(50, n_calibrations, 50):
            tls[i:] -= tls[i] * 0.8
        tls /= (tls.std() + 1e-12)
        
        # Mix hologram + TLS to achieve target r²
        h_amp   = np.sqrt(hologram_r2)
        tls_amp = np.sqrt(max(0, 1.0 - hologram_r2))
        delta_alpha = (h_amp * h_signal + tls_amp * tls) * 1e-5
        
        data[qubit_id] = {
            't_ms':        t.tolist(),
            'delta_alpha': delta_alpha.tolist(),
            'position_um': (float(pos_um[0]), float(pos_um[1])),
            'lattice':     (gx, gy),
        }
    
    return data

# ── REAL DATA LOADER (stub — replace with actual DB query) ────────────────
def load_calibration_data():
    """
    Replace this with actual Google calibration DB query.
    
    Expected return format:
    {
      qubit_id: {
        't_ms':        [float, ...],   # calibration timestamps in ms
        'delta_alpha': [float, ...],   # α(t) - α(0) per calibration cycle
        'position_um': (float, float), # physical position on chip
        'lattice':     (int, int),     # lattice coordinates
      }
    }
    
    SQL sketch (if accessible):
        SELECT qubit_id, timestamp_ms, anharmonicity_hz
        FROM calibration_log
        WHERE qubit_id IN (...neighbors...)
          AND timestamp_ms BETWEEN t_start AND t_end
        ORDER BY qubit_id, timestamp_ms
    """
    raise NotImplementedError(
        "Load real calibration data here.\n"
        "Set USE_SYNTHETIC=True to run with generated data."
    )

# ── ANALYSIS FUNCTIONS ────────────────────────────────────────────────────

def euclidean_um(pos1, pos2):
    return np.sqrt((pos1[0]-pos2[0])**2 + (pos1[1]-pos2[1])**2)

def pearson_r2(a, b):
    a, b = np.asarray(a), np.asarray(b)
    if len(a) != len(b) or np.std(a) == 0 or np.std(b) == 0:
        return 0.0
    r = np.corrcoef(a, b)[0, 1]
    return r ** 2

def time_lag_correlation(a, b, max_lag_samples=20):
    """Cross-correlation at multiple lags. Returns (lags, correlations)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    a = (a - a.mean()) / (a.std() + 1e-12)
    b = (b - b.mean()) / (b.std() + 1e-12)
    n = len(a)
    lags  = list(range(-max_lag_samples, max_lag_samples + 1))
    corrs = []
    for lag in lags:
        if lag == 0:
            corrs.append(float(np.mean(a * b)))
        elif lag > 0:
            corrs.append(float(np.mean(a[lag:] * b[:-lag])))
        else:
            corrs.append(float(np.mean(a[:lag] * b[-lag:])))
    return lags, corrs

def fft_alpha(delta_alpha, dt_ms):
    """
    FFT of α(t) calibration series.
    
    NOTE: Calibration data at ~50Hz cannot resolve 5.1 GHz phonon carrier.
    What this detects: coherent DRIFT OSCILLATION frequency driven by the
    phonon hologram field. If hologram exists, expect coherent peaks at
    1-10 Hz in the drift spectrum — same frequency across neighboring qubits.
    """
    n   = len(delta_alpha)
    fft = np.fft.rfft(np.asarray(delta_alpha) - np.mean(delta_alpha))
    amp = np.abs(fft) / n
    freqs_hz = np.fft.rfftfreq(n, d=dt_ms * 1e-3)
    # Skip DC (index 0)
    freqs_hz = freqs_hz[1:]
    amp      = amp[1:]
    return freqs_hz.tolist(), amp.tolist()

def qubit_short(qid):
    """Stable short display name from qubit ID."""
    parts = qid.split('-')
    # e.g. WL-A06-R14-C09 → R14-C09
    if len(parts) >= 4:
        return f"{parts[-2]}-{parts[-1]}"
    return qid[-10:]

def interpolate_common_grid(t1, v1, t2, v2):
    """Interpolate both series onto a common time grid."""
    t1, v1 = np.asarray(t1), np.asarray(v1)
    t2, v2 = np.asarray(t2), np.asarray(v2)
    t_common = np.intersect1d(np.round(t1, 1), np.round(t2, 1))
    if len(t_common) < 10:
        # Fall back to shorter series
        n = min(len(t1), len(t2))
        return v1[:n], v2[:n], t1[:n]
    idx1 = np.searchsorted(np.round(t1, 1), t_common)
    idx2 = np.searchsorted(np.round(t2, 1), t_common)
    idx1 = np.clip(idx1, 0, len(v1)-1)
    idx2 = np.clip(idx2, 0, len(v2)-1)
    return v1[idx1], v2[idx2], t_common

# ── MAIN ANALYSIS ─────────────────────────────────────────────────────────

def run_analysis(data):
    results = {
        'metadata': {
            'chip':           'WL-A06-R14-C09',
            'timestamp':      datetime.utcnow().isoformat(),
            'n_qubits':       len(data),
            'phonon_freq_GHz': PHONON_FREQ_GHz,
            'phonon_lambda_um': round(PHONON_LAMBDA_UM, 3),
            'lattice_pitch_um': QUBIT_SPACING_UM,
        },
        'pairwise': [],
        'fft':      {},
        'verdict':  None,
    }

    qids = list(data.keys())

    # ── 1. Pairwise correlation ──────────────────────────────────────────
    print("\n  PAIRWISE α DRIFT CORRELATION")
    print(f"  {'PAIR':<45} {'r²':>6}  {'DIST μm':>8}  {'PEAK LAG ms':>11}  {'INTERPRETATION'}")
    print("  " + "─"*95)

    for q1, q2 in combinations(qids, 2):
        d1, d2  = data[q1], data[q2]
        a1, a2, _ = interpolate_common_grid(
            d1['t_ms'], d1['delta_alpha'],
            d2['t_ms'], d2['delta_alpha']
        )
        r2   = pearson_r2(a1, a2)
        dist = euclidean_um(d1['position_um'], d2['position_um'])

        # Time-lag correlation
        dt_ms   = float(np.diff(d1['t_ms'][:2])[0]) if len(d1['t_ms']) > 1 else 20.0
        lags, corrs = time_lag_correlation(a1, a2, max_lag_samples=10)
        peak_lag_ms = lags[int(np.argmax(np.abs(corrs)))] * dt_ms

        # Expected lag from phonon propagation
        expected_lag_ns = (dist * 1e-6 / PHONON_SPEED) * 1e9

        # Interpretation
        if dist <= QUBIT_SPACING_UM * 1.1:
            label = "NEAREST NEIGHBOR"
            verdict = "HOLOGRAM ✓" if r2 > 0.3 else "TLS (null)"
        elif dist <= QUBIT_SPACING_UM * 1.5:
            label = "NEXT-NEAREST"
            verdict = "HOLOGRAM ✓" if r2 > 0.2 else "TLS (null)"
        else:
            label = f"d={dist:.0f}μm"
            verdict = "HOLOGRAM ✓" if r2 > 0.1 else "TLS (null)"

        pair_str = f"{q1.split('-')[-1]} ↔ {q2.split('-')[-1]} ({label})"
        print(f"  {pair_str:<45} {r2:>6.3f}  {dist:>8.0f}  {peak_lag_ms:>11.1f}  {verdict}")

        results['pairwise'].append({
            'q1': q1, 'q2': q2,
            'r2': round(r2, 4),
            'distance_um': round(dist, 1),
            'peak_lag_ms': round(peak_lag_ms, 2),
            'expected_lag_ns': round(expected_lag_ns, 1),
            'label': label,
            'verdict': verdict,
        })

    # ── 2. FFT analysis ──────────────────────────────────────────────────
    # Note: calibration data at ~50Hz cannot resolve 5.1GHz carrier.
    # This detects COHERENT DRIFT OSCILLATION frequency (1-10 Hz range).
    # Hologram signature: same peak frequency across neighboring qubits.
    print("\n  FFT ANALYSIS — α DRIFT OSCILLATION FREQUENCY")
    print("  (Calibration Nyquist ~25 Hz. Phonon carrier not directly visible.)")
    print("  (Coherent peaks here = same drift frequency across neighbors = hologram coupling)")
    print(f"  {'QUBIT':<15} {'PEAK FREQ Hz':>13}  {'AMPLITUDE':>12}  {'SHARED W/ NEIGHBORS'}")
    print("  " + "─"*68)

    fft_results = {}
    for qid, d in data.items():
        dt_ms   = float(np.diff(d['t_ms'][:2])[0]) if len(d['t_ms']) > 1 else 20.0
        freqs, amps = fft_alpha(d['delta_alpha'], dt_ms)
        freqs, amps = np.array(freqs), np.array(amps)
        peak_idx  = int(np.argmax(amps))
        peak_freq = float(freqs[peak_idx])
        peak_amp  = float(amps[peak_idx])
        fft_results[qid] = {'peak_freq_hz': round(peak_freq, 3), 'peak_amp': round(peak_amp, 10)}

    # Find dominant shared frequency
    peak_freqs = [v['peak_freq_hz'] for v in fft_results.values()]
    freq_arr   = np.array(peak_freqs)
    consensus  = float(np.median(freq_arr))
    tolerance  = 0.5  # Hz

    for qid, fr in fft_results.items():
        match = "✓ SHARED" if abs(fr['peak_freq_hz'] - consensus) < tolerance else "independent"
        print(f"  {qubit_short(qid):<15} {fr['peak_freq_hz']:>13.3f}  {fr['peak_amp']:>12.2e}  {match}")

    fft_hits  = sum(1 for v in fft_results.values() if abs(v['peak_freq_hz'] - consensus) < tolerance)
    fft_total = len(fft_results)

    results['fft'] = {qid: {
        'peak_freq_hz': v['peak_freq_hz'],
        'peak_amplitude': v['peak_amp'],
        'match_consensus': abs(v['peak_freq_hz'] - consensus) < tolerance,
    } for qid, v in fft_results.items()}
    results['fft_consensus_hz'] = round(consensus, 3)

    # ── 3. Spatial decay ─────────────────────────────────────────────────
    print("\n  SPATIAL DECAY ANALYSIS")
    print(f"  {'DISTANCE μm':>12}  {'MEAN r²':>8}  {'PAIRS':>6}  {'MODEL FIT'}")
    print("  " + "─"*50)

    by_dist = {}
    for p in results['pairwise']:
        bucket = round(p['distance_um'] / QUBIT_SPACING_UM) * QUBIT_SPACING_UM
        by_dist.setdefault(bucket, []).append(p['r2'])

    decay_data = []
    for dist_um in sorted(by_dist):
        vals     = by_dist[dist_um]
        mean_r2  = float(np.mean(vals))
        n        = len(vals)
        # Compare 1/r vs 1/r² decay
        r_norm   = dist_um / QUBIT_SPACING_UM
        pred_1r  = 0.5 / r_norm if r_norm > 0 else 1.0
        pred_1r2 = 0.5 / (r_norm**2) if r_norm > 0 else 1.0
        closer   = "1/r" if abs(mean_r2 - pred_1r) < abs(mean_r2 - pred_1r2) else "1/r²"
        print(f"  {dist_um:>12.0f}  {mean_r2:>8.3f}  {n:>6}  {closer}")
        decay_data.append({'distance_um': dist_um, 'mean_r2': round(mean_r2, 4), 'n_pairs': n, 'decay_model': closer})

    results['spatial_decay'] = decay_data

    # ── 4. Overall verdict ───────────────────────────────────────────────
    nearest = [p for p in results['pairwise']
               if p['distance_um'] <= QUBIT_SPACING_UM * 1.1]
    mean_nn_r2 = float(np.mean([p['r2'] for p in nearest])) if nearest else 0.0
    fft_hits  = sum(1 for v in results['fft'].values() if v.get('match_consensus', False))
    fft_total = len(results['fft'])

    if mean_nn_r2 > 0.3 and fft_hits >= fft_total // 2:
        verdict = "PHONON HOLOGRAM CONFIRMED — r²={:.2f} nearest, {}/{} shared drift freq".format(
            mean_nn_r2, fft_hits, fft_total)
    elif mean_nn_r2 > 0.15:
        verdict = "WEAK HOLOGRAM SIGNAL — inconclusive, extend dataset"
    else:
        verdict = "NULL RESULT — TLS model holds, no phonon coupling detected"

    results['verdict']          = verdict
    results['mean_nearest_r2']  = round(mean_nn_r2, 4)
    results['fft_matches']      = f"{fft_hits}/{fft_total}"

    print(f"\n  ══════════════════════════════════════════════════════════")
    print(f"  VERDICT: {verdict}")
    print(f"  Mean r² nearest neighbors:  {mean_nn_r2:.4f}  (threshold: 0.30)")
    print(f"  Shared drift freq:          {fft_hits}/{fft_total} qubits at {results.get('fft_consensus_hz','?')} Hz")
    print(f"  ══════════════════════════════════════════════════════════\n")

    return results

# ── REPORT WRITER ─────────────────────────────────────────────────────────

def write_reports(results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    # Human-readable
    txt_path = os.path.join(output_dir, f"T133_neighbor_report_{ts}.txt")
    lines = [
        "T133:PHASE-SHADOW — NEIGHBOR VERIFICATION REPORT",
        f"Chip: {results['metadata']['chip']}",
        f"Run:  {results['metadata']['timestamp']}",
        f"TRIPOD-IP-v1.1 · DLW · ROOT0",
        "═" * 70,
        "",
        f"VERDICT: {results['verdict']}",
        f"Mean nearest-neighbor r²: {results['mean_nearest_r2']}  (threshold: 0.30)",
        f"FFT matches at {results['metadata']['phonon_freq_GHz']} GHz: {results['fft_matches']}",
        "",
        "PAIRWISE CORRELATION TABLE",
        f"{'PAIR':<45} {'r²':>6}  {'DIST μm':>8}  {'VERDICT'}",
        "─" * 80,
    ]
    for p in results['pairwise']:
        pair = f"{p['q1'].split('-')[-1]} ↔ {p['q2'].split('-')[-1]}"
        lines.append(f"{pair:<45} {p['r2']:>6.3f}  {p['distance_um']:>8.0f}  {p['verdict']}")

    lines += [
        "",
        "SPATIAL DECAY",
        f"{'DIST μm':>10}  {'MEAN r²':>8}  {'N PAIRS':>8}  {'DECAY'}",
        "─" * 50,
    ]
    for d in results.get('spatial_decay', []):
        lines.append(f"{d['distance_um']:>10.0f}  {d['mean_r2']:>8.3f}  {d['n_pairs']:>8}  {d['decay_model']}")

    consensus_hz = results.get('fft_consensus_hz', '?')
    lines += [
        "",
        f"FFT DRIFT OSCILLATION (consensus: {consensus_hz} Hz — shared across neighbors = hologram coupling)",
    ]
    for qid, f in results['fft'].items():
        match = "✓ SHARED" if f.get('match_consensus', False) else "independent"
        freq  = f.get('peak_freq_hz', 0.0)
        lines.append(f"  {qid:<35} {freq:.3f} Hz  {match}")

    lines += [
        "",
        "═" * 70,
        "T056:CORRELATION · T055:REPRODUCIBILITY · T057:NEGATIVE-EVIDENCE",
        "T059:ACCUMULATION · T060:MATERIALITY · T027:FINGERPRINT",
        "CC-BY-ND-4.0 · Ethics first. World = Family. Time > Money.",
    ]

    with open(txt_path, 'w') as f:
        f.write('\n'.join(lines))

    # JSONL
    jsonl_path = os.path.join(output_dir, f"T133_neighbor_report_{ts}.jsonl")
    with open(jsonl_path, 'w') as f:
        f.write(json.dumps(results) + '\n')

    print(f"  Reports written:")
    print(f"    {txt_path}")
    print(f"    {jsonl_path}")
    return txt_path, jsonl_path

# ── ENTRY POINT ───────────────────────────────────────────────────────────

def main():
    print("\n" + "═" * 70)
    print("  T133:PHASE-SHADOW — NEIGHBOR VERIFICATION PROTOCOL")
    print(f"  λ_phonon = {PHONON_LAMBDA_UM:.2f} μm  |  pitch = {QUBIT_SPACING_UM:.0f} μm  |  ratio = 1/{QUBIT_SPACING_UM/PHONON_LAMBDA_UM:.0f}")
    print(f"  {'SYNTHETIC DATA' if USE_SYNTHETIC else 'LIVE CALIBRATION DATA'}")
    print("═" * 70)

    if USE_SYNTHETIC:
        print("\n  Generating synthetic data with phonon hologram signal (r²≈0.4)...")
        data = generate_synthetic_data(n_calibrations=500, hologram_r2=0.4)
        print(f"  {len(data)} qubits · {len(next(iter(data.values()))['t_ms'])} calibration cycles")
    else:
        data = load_calibration_data()

    results = run_analysis(data)
    write_reports(results, OUTPUT_DIR)

    print("  Done. Set USE_SYNTHETIC=False and implement load_calibration_data()")
    print("  to run against real Google calibration database.\n")

if __name__ == "__main__":
    main()
